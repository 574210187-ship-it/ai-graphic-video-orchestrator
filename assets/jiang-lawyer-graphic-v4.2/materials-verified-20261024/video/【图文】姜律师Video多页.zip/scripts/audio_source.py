"""Choose the first readable audio source in the fixed package priority order."""
from fractions import Fraction
import json
import math


def prepare(job, work, probe, command):
    """Prepare one audio track, falling through unavailable sources safely.

    Priority is: the initial reference video's track, a video explicitly
    assigned as the music source in the same edit box, then an independent
    audio file from that edit box. If none is readable, use six seconds of
    silence.
    """
    candidates = [
        ('initial_reference_video', job.get('reference_video')),
        ('specified_video_audio', job.get('video_audio_source')),
        ('explicit_audio_source', job.get('audio_source')),
    ]
    requested_stream = job.get('audio_stream')
    if requested_stream is not None and type(requested_stream) is not int:
        raise ValueError('audio_stream must be an absolute integer stream index')
    attempts = []

    def silent(reason):
        silent_duration = float(job.get('silent_duration', 6.0))
        if not math.isfinite(silent_duration) or silent_duration <= 0:
            raise ValueError('silent_duration must be positive')
        silent_ticks = int(round(silent_duration * 30000))
        result = {'has_audio': False, 'path': None, 'source': None,
                  'selection': 'none', 'fallback_chain': attempts,
                  'fallback_reason': reason,
                  'duration': silent_ticks / 30000.0, 'duration_ticks': silent_ticks, 'timescale': 30000}
        (work / 'audio_source_plan.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
        return result

    for selection, raw_source in candidates:
        if not raw_source:
            attempts.append({'selection': selection, 'status': 'unavailable', 'reason': 'not_provided'})
            continue
        source = str(raw_source)
        try:
            info = probe(source)
        except (RuntimeError, OSError, ValueError) as exc:
            attempts.append({'selection': selection, 'source': source,
                             'status': 'unavailable', 'reason': f'probe_failed: {exc}'})
            continue
        tracks = [s for s in info.get('streams', []) if s.get('codec_type') == 'audio']
        if not tracks:
            attempts.append({'selection': selection, 'source': source,
                             'status': 'unavailable', 'reason': 'no_audio_track'})
            continue
        if requested_stream is not None:
            matching = [s for s in tracks if s.get('index') == requested_stream]
            if not matching:
                attempts.append({'selection': selection, 'source': source,
                                 'status': 'unavailable', 'reason': 'audio_stream_not_found'})
                continue
            track = matching[0]
        else:
            track = next((s for s in tracks if s.get('disposition', {}).get('default')), tracks[0])
        sr = int(track['sample_rate'])
        source_start = float(track.get('start_time', 0))
        audio_path = work / 'source_audio.m4a'
        if track['codec_name'] == 'aac':
            args = ['ffmpeg', '-y', '-v', 'error', '-copyts', '-itsoffset', str(-source_start), '-i', source,
                    '-map', f"0:{track['index']}", '-vn', '-c:a', 'copy']
        else:
            args = ['ffmpeg', '-y', '-v', 'error', '-i', source, '-map', f"0:{track['index']}",
                    '-vn', '-af', 'asetpts=PTS-STARTPTS', '-c:a', 'aac', '-b:a', '192k']
        args += ['-map_metadata', '-1', '-avoid_negative_ts', 'disabled', '-movie_timescale', str(sr),
                 '-movflags', '+faststart', str(audio_path)]
        try:
            command(args, work / 'audio_extract.log')
            extracted = next(s for s in probe(audio_path)['streams'] if s['codec_type'] == 'audio')
            duration = (Fraction(extracted['duration_ts']) * Fraction(extracted['time_base'])
                        if extracted.get('duration_ts') is not None else Fraction(extracted['duration']))
            if duration <= 0 or not math.isfinite(float(duration)):
                raise ValueError('the audio track has no valid playable duration')
        except (RuntimeError, OSError, StopIteration, KeyError, ValueError, ZeroDivisionError) as exc:
            attempts.append({'selection': selection, 'source': source,
                             'status': 'unavailable', 'reason': f'extraction_failed: {exc}'})
            continue
        offset = Fraction(0)
        total = offset + duration
        scale = math.lcm(30, sr, total.denominator, offset.denominator)
        attempts.append({'selection': selection, 'source': source, 'status': 'selected',
                         'stream_index': track['index']})
        result = {'has_audio': True, 'path': str(audio_path), 'source': source,
                  'selection': selection, 'fallback_chain': attempts,
                  'stream_index': track['index'],
                  'duration': float(total), 'audio_duration': float(duration),
                  'duration_ticks': int(total * scale), 'timescale': scale,
                  'mux_offset': float(offset), 'sample_rate': int(extracted['sample_rate']),
                  'channels': extracted['channels'], 'copied_aac': track['codec_name'] == 'aac'}
        (work / 'audio_source_plan.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
        return result
    return silent('no_readable_audio_source')


def packet_timing(sound, count, last_pts, cfr=False):
    scale = sound['timescale']
    last = sound['duration_ticks'] - round(last_pts * scale)
    if last <= 0:
        raise ValueError('Last video frame must start before the audio endpoint')
    if cfr:
        step = scale // 30
        return (f'setts=time_base=1/{scale}:pts=N*{step}:dts=N*{step}:'
                f'duration=if(eq(N\\,{count-1})\\,{last}\\,{step})')
    return (f'setts=time_base=1/{scale}:pts=PTS*TB*{scale}:dts=DTS*TB*{scale}:'
            f'duration=if(eq(N\\,{count-1})\\,{last}\\,DURATION*TB*{scale})')
