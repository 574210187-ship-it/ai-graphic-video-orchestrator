#!/usr/bin/env python3
"""System A Video 04 multi-page renderer; MP4 only, no browser or network."""
import argparse
import bisect
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

VERSION = '5.8.0-multi-page-combined-text-layers'
FPS = 30
PAGE_TRANSITION = 0.28
BODY_REVEAL_MIN = 0.62
BODY_REVEAL_MAX = 1.55
BODY_REVEAL_PER_ROW = 0.25
BREATH_PERIOD = 4.0
LIGHT_EFFECT_WINDOW = 2.2
LIGHT_EFFECT_GAP = 1.0
LIGHT_EFFECT_MAX_ALPHA = 96
DEFAULT_PAGE_DURATION = 4.0
DEFAULT_CRF = 20
DEFAULT_PRESET = 'medium'
VIDEO_PROFILE = 'high'
VIDEO_LEVEL = '5.2'
VIDEO_MAXRATE = '10M'
VIDEO_BUFSIZE = '20M'
DEFAULT_TITLE_BOX = (.08, .06, .92, .28)
DEFAULT_BODY_BOX = (.10, .28, .90, .91)
TITLE_BODY_GAP_TARGET = .055
TITLE_BODY_GAP_MIN = .04
TITLE_BODY_GAP_MAX = .07
MIN_BODY_SCALE = .80
ALPHA_LAYOUT_THRESHOLD = 16
ROW_ALPHA_THRESHOLD = 24
ROW_SCORE_MIN = 6.0


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for part in iter(lambda: f.read(1048576), b''):
            h.update(part)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.partial')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def command(args, log=None):
    if log:
        with open(log, 'ab') as stream:
            result = subprocess.run(args, stdout=stream, stderr=stream)
        if result.returncode:
            tail = Path(log).read_text(errors='replace')[-3000:]
            raise RuntimeError(f'Command failed ({result.returncode}): {tail}')
        return None
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace')[-3000:])
    return result.stdout


def probe(path, frames=False):
    args = ['ffprobe', '-v', 'error', '-show_streams', '-show_format']
    if frames:
        args += ['-select_streams', 'v:0', '-show_frames',
                 '-show_entries', 'frame=best_effort_timestamp_time,pts_time,pkt_duration_time,duration_time']
    args += ['-of', 'json', str(path)]
    return json.loads(command(args))


def video_stream(info):
    return next(s for s in info['streams'] if s['codec_type'] == 'video')


def frame_times(info):
    return [float(f.get('best_effort_timestamp_time', f.get('pts_time'))) for f in info['frames']]


def check_environment():
    import importlib.util
    missing = [x for x in ('ffmpeg', 'ffprobe') if not shutil.which(x)]
    missing += [x for x in ('PIL', 'numpy') if importlib.util.find_spec(x) is None]
    enc = command(['ffmpeg', '-hide_banner', '-encoders']).decode() if not missing else ''
    if not missing and 'libx264' not in enc:
        missing.append('FFmpeg libx264 encoder')
    if not missing and ' aac ' not in enc:
        missing.append('FFmpeg AAC encoder')
    return {'engine_version': VERSION, 'ready': not missing, 'missing': missing,
            'browser_required': False, 'network_required': False}


def image(path, mode='RGBA'):
    from PIL import Image, ImageOps
    im = Image.open(path)
    if im.info.get('icc_profile'):
        raise ValueError(f'ICC profile needs explicit sRGB normalization first: {path}')
    im = ImageOps.exif_transpose(im)
    if im.mode in ('I', 'F') or im.mode.startswith('I;16'):
        raise ValueError('Normalize high-bit-depth input explicitly before rendering')
    im = im.convert('RGBA')
    if mode == 'RGB' and im.getchannel('A').getextrema() != (255, 255):
        raise ValueError(f'Opaque image required: {path}')
    return im.convert(mode)


def positive_video_duration(info, stream, path):
    """Return a finite source duration; looping an indeterminate stream is unsafe."""
    values = [info.get('format', {}).get('duration'), stream.get('duration')]
    for value in values:
        try:
            duration = float(value)
        except (TypeError, ValueError):
            continue
        if math.isfinite(duration) and duration > 0:
            return duration
    raise ValueError(f'background_video must have a finite positive duration: {path}')


def video_background_frame(source, t):
    """Decode one visual background frame at t modulo its natural duration.

    This is used only for review/profile frames. Final output is decoded through
    one sequential looped FFmpeg reader, so the source's native frame order is
    retained and no per-frame seeking occurs during encoding.
    """
    from PIL import Image
    duration = source['source_duration']
    local_t = max(0.0, float(t)) % duration
    w, h = source['canvas_size']
    raw = command(['ffmpeg', '-v', 'error', '-ss', f'{local_t:.9f}', '-i', source['path'],
                   '-map', '0:v:0', '-an', '-frames:v', '1',
                   '-vf', f'scale={w}:{h}:flags=lanczos', '-pix_fmt', 'rgb24',
                   '-f', 'rawvideo', 'pipe:1'])
    expected = w * h * 3
    if len(raw) != expected:
        raise ValueError(f'Could not decode one full background-video frame at {local_t:.3f}s')
    return Image.frombytes('RGB', (w, h), raw)


def prepare_background(job):
    """Validate exactly one background source and determine the render canvas."""
    still = job.get('background')
    video = job.get('background_video')
    if bool(still) == bool(video):
        raise ValueError('Provide exactly one of background (opaque image) or background_video (video)')
    if still:
        background = image(still)
        if background.getchannel('A').getextrema() != (255, 255):
            raise ValueError('background must be opaque')
        background = background.convert('RGB')
        return {'kind': 'image', 'path': str(still), 'canvas_size': background.size,
                'preview': background, 'loop_policy': 'not_applicable',
                'source_audio_used': False}
    info = probe(video)
    try:
        stream = video_stream(info)
    except StopIteration as exc:
        raise ValueError(f'background_video has no readable video stream: {video}') from exc
    width, height = int(stream.get('width', 0)), int(stream.get('height', 0))
    if width < 2 or height < 2:
        raise ValueError(f'background_video has invalid dimensions: {video}')
    # yuv420p/H.264 needs even coded dimensions. The video itself defines the
    # canvas, and title/body artwork is fitted to that same canvas.
    canvas = (width + width % 2, height + height % 2)
    source = {'kind': 'video', 'path': str(video), 'source_duration': positive_video_duration(info, stream, video),
              'source_size': [width, height], 'canvas_size': canvas,
              'loop_policy': 'chosen_after_final_output_duration_is_known',
              'source_audio_used': False}
    source['preview'] = video_background_frame(source, 0.0)
    return source


def background_at(source, t):
    if source['kind'] == 'image':
        return source['preview']
    return video_background_frame(source, t)


def open_background_reader(source, frame_count, output_duration, log):
    """Stream the source once when sufficient, otherwise loop it in source order."""
    if source['kind'] != 'video':
        return None, False
    w, h = source['canvas_size']
    repeat = output_duration > source['source_duration'] + 1e-9
    args = ['ffmpeg', '-v', 'error']
    if repeat:
        args += ['-stream_loop', '-1']
    args += ['-i', source['path'],
            '-map', '0:v:0', '-an', '-vf', f'fps={FPS},scale={w}:{h}:flags=lanczos',
            '-frames:v', str(frame_count), '-pix_fmt', 'rgb24', '-f', 'rawvideo', 'pipe:1']
    return subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=log), repeat


def compare(a, b):
    import numpy as np
    x, y = np.asarray(a).astype('int16'), np.asarray(b).astype('int16')
    if x.shape != y.shape:
        raise ValueError(f'Different shapes: {x.shape} / {y.shape}')
    diff = np.abs(x - y)
    return {'different_pixels': int(np.any(diff != 0, axis=2).sum()),
            'max_channel_error': int(diff.max())}


def even_frame(frame):
    import numpy as np
    from PIL import Image
    w, h = frame.size
    if w % 2 or h % 2:
        return Image.fromarray(np.pad(np.asarray(frame), ((0, h % 2), (0, w % 2), (0, 0)), mode='edge'))
    return frame


def alpha_scaled(layer, amount):
    from PIL import Image
    if amount >= 0.999999:
        return layer
    out = layer.copy()
    out.putalpha(out.getchannel('A').point(lambda p: round(p * max(0.0, min(1.0, amount)))))
    return out


def alpha_composite(base, layer, amount=1.0):
    from PIL import Image
    return Image.alpha_composite(base.convert('RGBA'), alpha_scaled(layer, amount)).convert('RGB')


def normalize_box(box, name):
    if not isinstance(box, (list, tuple)) or len(box) != 4:
        raise ValueError(f'{name} must be [x0,y0,x1,y1] normalized to 0..1')
    x0, y0, x1, y1 = [float(v) for v in box]
    if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
        raise ValueError(f'{name} must be ordered normalized coordinates within 0..1')
    return (x0, y0, x1, y1)


def visible_alpha_bbox(layer, threshold=ALPHA_LAYOUT_THRESHOLD):
    """Measure actual artwork, ignoring near-transparent full-canvas haze."""
    alpha = layer.getchannel('A')
    bbox = alpha.point(lambda p: 255 if p >= threshold else 0).getbbox()
    if not bbox:
        raise ValueError('transparent layer has no visible artwork above layout threshold')
    return bbox


def normalized_bbox(bbox, size):
    x0, y0, x1, y1 = bbox; w, h = size
    return [x0 / w, y0 / h, x1 / w, y1 / h]


def crop_visible(layer, label):
    bbox = visible_alpha_bbox(layer)
    crop = layer.crop(bbox)
    if crop.width < 2 or crop.height < 2:
        raise ValueError(f'{label} has no usable visible area')
    return crop, bbox


def place_crop(crop, canvas_size, x, y, scale):
    from PIL import Image
    w, h = canvas_size
    nw, nh = max(1, round(crop.width * scale)), max(1, round(crop.height * scale))
    resized = crop.resize((nw, nh), Image.Resampling.LANCZOS)
    out = Image.new('RGBA', canvas_size)
    out.alpha_composite(resized, (round(x), round(y)))
    return out


def fit_body(layer, canvas_size, title_bbox, body_box, label):
    """Place each page beneath the actual placed title, preserving aspect ratio."""
    crop, source_bbox = crop_visible(layer, label)
    cw, ch = canvas_size; x0, _, x1, y1 = normalize_box(body_box, f'{label}_box')
    title_bottom = title_bbox[3]
    target_gap = round(ch * TITLE_BODY_GAP_TARGET)
    body_top = title_bottom + target_gap
    body_bottom = round(y1 * ch)
    available_w, available_h = (x1 - x0) * cw, body_bottom - body_top
    if available_h <= 0:
        raise ValueError(f'{label} has no vertical safe area below title')
    desired_w = available_w * .975
    scale = min(desired_w / crop.width, available_h / crop.height)
    if scale < MIN_BODY_SCALE:
        raise ValueError(f'{label} is too dense for the safe body area (scale {scale:.3f} < {MIN_BODY_SCALE:.2f}); split it into another body page')
    out = place_crop(crop, canvas_size, (cw - crop.width * scale) / 2, body_top, scale)
    bbox = visible_alpha_bbox(out)
    gap = bbox[1] - title_bottom
    if not round(ch * TITLE_BODY_GAP_MIN) <= gap <= round(ch * TITLE_BODY_GAP_MAX):
        raise ValueError(f'{label} title/body gap {gap}px violates {TITLE_BODY_GAP_MIN:.0%}–{TITLE_BODY_GAP_MAX:.0%} canvas-height rule')
    return out, {'label': label, 'mode': 'adaptive_visible_bounds',
                 'source_size': list(layer.size), 'source_visible_box': normalized_bbox(source_bbox, layer.size),
                 'target_box': [x0, body_top / ch, x1, y1], 'scale': scale,
                 'visible_box': normalized_bbox(bbox, canvas_size), 'title_body_gap_px': gap,
                 'title_body_gap_fraction': gap / ch}


def fit_combined_text(layer, canvas_size, label):
    """Accept one title+body text PNG; preserve matching canvases, otherwise fit it once."""
    from PIL import Image
    if layer.size == canvas_size:
        bbox = visible_alpha_bbox(layer)
        return layer.copy(), {'label': label, 'mode': 'same_canvas',
                              'source_size': list(layer.size),
                              'source_visible_box': normalized_bbox(bbox, layer.size),
                              'visible_box': normalized_bbox(bbox, canvas_size), 'scale': 1.0}
    crop, source_bbox = crop_visible(layer, label)
    cw, ch = canvas_size
    x0, y0, x1, y1 = (.08, .06, .92, .91)
    available_w, available_h = (x1 - x0) * cw, (y1 - y0) * ch
    scale = min(available_w * .95 / crop.width, available_h * .95 / crop.height)
    out = place_crop(crop, canvas_size, (cw - crop.width * scale) / 2, y0 * ch, scale)
    bbox = visible_alpha_bbox(out)
    return out, {'label': label, 'mode': 'adaptive_combined_text',
                 'source_size': list(layer.size), 'source_visible_box': normalized_bbox(source_bbox, layer.size),
                 'visible_box': normalized_bbox(bbox, canvas_size), 'scale': scale}


def split_combined_text(text_layer):
    """Create temporary header/body masks from one supplied text layer; no separate input layer exists."""
    import numpy as np
    from PIL import Image
    cut = round(text_layer.height * DEFAULT_TITLE_BOX[3])
    source = np.asarray(text_layer)
    header = source.copy(); header[cut:, :, 3] = 0
    body = source.copy(); body[:cut, :, 3] = 0
    header = Image.fromarray(header)
    body = Image.fromarray(body)
    if header.getchannel('A').getextrema()[1] == 0:
        raise ValueError('Each text layer must keep its common title within the upper title zone')
    if body.getchannel('A').getextrema()[1] == 0:
        raise ValueError('Each text layer must include body content below the title zone')
    return header, body


def _runs(active, minimum=2, merge_gap=0):
    runs = []
    start = None
    for i, on in enumerate(active):
        if on and start is None:
            start = i
        elif not on and start is not None:
            if i - start >= minimum:
                runs.append((start, i))
            start = None
    if start is not None and len(active) - start >= minimum:
        runs.append((start, len(active)))
    if merge_gap <= 0 or not runs:
        return runs
    merged = [runs[0]]
    for start, stop in runs[1:]:
        if start - merged[-1][1] <= merge_gap:
            merged[-1] = (merged[-1][0], stop)
        else:
            merged.append((start, stop))
    return merged


def _visual_body_rows(layer):
    """Find true horizontal text bands even if a panel joins body alpha together."""
    import numpy as np
    rgba = np.asarray(layer).astype('float32')
    rgb, alpha = rgba[:, :, :3], rgba[:, :, 3]
    gray = .299 * rgb[:, :, 0] + .587 * rgb[:, :, 1] + .114 * rgb[:, :, 2]
    gx = np.abs(gray[:, 1:] - gray[:, :-1]).mean(axis=1)
    gy = np.abs(gray[1:, :] - gray[:-1, :]).mean(axis=1)
    score = np.zeros(gray.shape[0], dtype='float32')
    score[1:-1] = gx[1:-1] + np.maximum(gy[:-1], gy[1:])
    smooth_window = max(5, min(15, layer.height // 180))
    score = np.convolve(score, np.ones(smooth_window, dtype='float32') / smooth_window, mode='same')
    score[alpha.max(axis=1) <= ROW_ALPHA_THRESHOLD] = 0
    active_scores = score[score > 0]
    if not active_scores.size or float(active_scores.max()) <= ROW_SCORE_MIN:
        return []
    threshold = max(ROW_SCORE_MIN, float(np.percentile(active_scores, 55)) * .8)
    return _runs(score >= threshold, minimum=max(3, layer.height // 800),
                 merge_gap=max(3, layer.height // 500))


def infer_body_row_units(layer):
    """Return independently revealable visual rows; never treat one full body sheet as one fade."""
    import numpy as np
    alpha = np.asarray(layer.getchannel('A'))
    active = alpha.max(axis=1) > ROW_ALPHA_THRESHOLD
    alpha_runs = _runs(active, minimum=max(2, layer.height // 800),
                       merge_gap=max(3, layer.height // 500))
    visual_runs = _visual_body_rows(layer)
    # A large alpha run is normally the panel. Prefer visual text rows in that case.
    if len(visual_runs) > 1:
        return visual_runs
    if len(alpha_runs) > 1 and not any((b - a) > max(300, int(layer.height * .24))
                                       for a, b in alpha_runs):
        return alpha_runs
    if visual_runs:
        return visual_runs
    if alpha_runs:
        return alpha_runs
    raise ValueError('body layer has no revealable text row')


def body_row_bands(row_units, height):
    if not row_units or any(not (0 <= a < b <= height) for a, b in row_units):
        raise ValueError('body row units are invalid')
    if any(b > c for (_, b), (c, _) in zip(row_units, row_units[1:])):
        raise ValueError('body row units must be ordered and non-overlapping')
    cuts = [0] + [(b + c) // 2 for (_, b), (c, _) in zip(row_units, row_units[1:])] + [height]
    return list(zip(cuts, cuts[1:]))


def body_row_schedule(row_units, start, end):
    """Fit sequential row entrances inside the page's own display interval."""
    count = len(row_units)
    available = float(end) - float(start)
    if count < 1 or available < .42:
        raise ValueError('page display interval is too short for sequential body rows')
    desired = max(BODY_REVEAL_MIN, BODY_REVEAL_PER_ROW * count)
    total = min(BODY_REVEAL_MAX, desired, available * .72)
    if total < .38:
        raise ValueError('page display interval leaves no readable row-reveal time')
    step = total / count
    window = min(.34, max(.14, step * .90))
    return [(start + i * step, start + i * step + window) for i in range(count)]


def sequential_body_rows(layer, row_units, schedule, t):
    """Reveal one actual body row/card at a time, keeping source RGBA intact once settled."""
    import numpy as np
    from PIL import Image
    src = np.asarray(layer)
    out = src.copy(); out[:, :, 3] = 0
    for (y0, y1), (begin, finish) in zip(body_row_bands(row_units, layer.height), schedule):
        progress = ease((t - begin) / max(1e-9, finish - begin))
        unit = src[y0:y1].copy()
        unit[:, :, 3] = np.rint(unit[:, :, 3] * progress).astype('uint8')
        columns = np.flatnonzero(src[y0:y1, :, 3].max(axis=0))
        dx = round(min(2, layer.width - 1 - int(columns[-1])) * (1.0 - progress)) if columns.size else 0
        if dx:
            out[y0:y1, dx:] = unit[:, :-dx]
        else:
            out[y0:y1] = unit
    return Image.fromarray(out)


def audit_body_row_reveals(layer, row_units, schedule):
    """Fail if any future body row leaks before its own scheduled entrance."""
    import numpy as np
    bands = body_row_bands(row_units, layer.height)
    checks = []
    for i, ((y0, y1), (start, end)) in enumerate(zip(bands, schedule)):
        before = np.asarray(sequential_body_rows(layer, row_units, schedule, max(0, start - 1e-6)))
        during = np.asarray(sequential_body_rows(layer, row_units, schedule, (start + end) / 2))
        after = np.asarray(sequential_body_rows(layer, row_units, schedule, end + 1e-6))
        if before[y0:y1, :, 3].any():
            raise ValueError(f'BODY_ROW_AUDIT_FAIL: row {i + 1} appeared early')
        if not during[y0:y1, :, 3].any():
            raise ValueError(f'BODY_ROW_AUDIT_FAIL: row {i + 1} did not enter')
        if not np.array_equal(after[:y1], np.asarray(layer)[:y1]):
            raise ValueError(f'BODY_ROW_AUDIT_FAIL: row {i + 1} did not settle exactly')
        if during[y1:, :, 3].any():
            raise ValueError(f'BODY_ROW_AUDIT_FAIL: future rows appeared during row {i + 1}')
        checks.append({'row': i + 1, 'start': round(start, 6), 'end': round(end, 6),
                       'before_hidden': True, 'during_visible': True, 'settled_rgba_exact': True})
    return checks


def ease(u):
    u = max(0.0, min(1.0, float(u)))
    return u * u * (3.0 - 2.0 * u)


def page_state(t, pages, starts):
    """Return current/previous page indices and eased transition progress."""
    n = len(pages)
    if t < starts[0]:
        return 0, None, 0.0
    if n == 1:
        return 0, None, 1.0
    idx = min(n - 1, max(0, bisect.bisect_right(starts, t) - 1))
    local = t - starts[idx]
    if idx == 0:
        return 0, None, 1.0
    if local < PAGE_TRANSITION:
        return idx, idx - 1, ease(local / PAGE_TRANSITION)
    return idx, None, 1.0


def compose_layers(background, title, current_body, previous_body=None, transition=1.0):
    """Fixed background and title with a page transition around sequential body rows."""
    from PIL import Image
    out = Image.alpha_composite(background.convert('RGBA'), title)
    if previous_body is not None:
        out = Image.alpha_composite(out, alpha_scaled(previous_body, 1.0 - transition))
        out = Image.alpha_composite(out, alpha_scaled(current_body, transition))
    else:
        out = Image.alpha_composite(out, current_body)
    return out.convert('RGB')


def breathe_background(background, t):
    """Apply the 4 s breathing movement to the background only, from frame 0."""
    from PIL import Image
    scale = 1 + .006 * (1 - math.cos(2 * math.pi * t / BREATH_PERIOD))
    if abs(scale - 1) < 1e-12:
        return background
    w, h = background.size
    return background.transform((w, h), Image.Transform.AFFINE,
        (1 / scale, 0, w / 2 - w / (2 * scale), 0, 1 / scale, h / 2 - h / (2 * scale)),
        resample=Image.Resampling.BICUBIC)


def light_effect_profile(reference, duration):
    import numpy as np
    import random
    small = np.asarray(reference.resize((48, 48))).astype('float32')
    mean = small.mean(axis=(0, 1)); r, g, b = [float(x) for x in mean]
    if r > b * 1.14 and r > g * 1.03:
        palette, family = ((255, 210, 135), (255, 155, 95)), 'warm_gold'
    elif b > r * 1.12:
        palette, family = ((235, 255, 255), (255, 255, 255)), 'cool_white_cyan'
    elif g > r * 1.08 and g > b * 1.05:
        palette, family = ((175, 255, 215), (255, 225, 145)), 'soft_cyan'
    else:
        palette, family = ((255, 246, 220), (205, 190, 255)), 'neutral_lens'
    seed = int(hashlib.sha256(reference.tobytes()).hexdigest()[:16], 16)
    rng = random.Random(seed)
    count = max(1, math.ceil(max(0.0, duration) / (LIGHT_EFFECT_WINDOW + LIGHT_EFFECT_GAP)) + 1)
    events = []; prev = None; kind_prev = None
    for _ in range(count):
        kinds = [k for k in range(3) if k != kind_prev]
        kind = rng.choice(kinds)
        for attempt in range(24):
            x0, y0 = rng.uniform(.12, .88), rng.uniform(.12, .88)
            x1 = min(.88, max(.12, x0 + rng.uniform(-.32, .32)))
            y1 = min(.88, max(.12, y0 + rng.uniform(-.32, .32)))
            if prev is None or math.hypot(x0 - prev[0], y0 - prev[1]) >= .28 or attempt == 23:
                break
        events.append({'kind': kind, 'color': rng.randrange(2), 'x0': x0, 'y0': y0,
                       'x1': x1, 'y1': y1, 'angle': rng.uniform(0, 2 * math.pi)})
        prev, kind_prev = (x1, y1), kind
    return {'family': family, 'palette': palette, 'seed': seed, 'events': events,
            'intensity': max(.62, min(1.0, .72 + (0.2126*r + 0.7152*g + 0.0722*b) / 900.0))}


def light_rgba(size, event, u, profile):
    import numpy as np
    from PIL import Image
    w, h = size; sw, sh = max(96, w // 4), max(128, h // 4)
    yy, xx = np.mgrid[0:sh, 0:sw].astype('float32'); x = xx / max(1, sw - 1); y = yy / max(1, sh - 1)
    cx = event['x0'] + (event['x1'] - event['x0']) * u; cy = event['y0'] + (event['y1'] - event['y0']) * u
    color = profile['palette'][event['color']]; angle = event['angle']
    if event['kind'] == 0:
        along = (x-cx)*math.cos(angle) + (y-cy)*math.sin(angle)
        across = -(x-cx)*math.sin(angle) + (y-cy)*math.cos(angle)
        glow = np.exp(-(along/.34)**2 - (across/.080)**2) + .26*np.exp(-(along/.46)**2-(across/.16)**2)
        strength = .96
    elif event['kind'] == 1:
        radius = np.sqrt(((x-cx)/.32)**2 + ((y-cy)/.22)**2)
        glow = np.exp(-(radius/.82)**2) + .28*np.exp(-(radius/1.45)**2); strength = .92
    else:
        along = (x-cx)*math.cos(angle) + (y-cy)*math.sin(angle)
        across = -(x-cx)*math.sin(angle) + (y-cy)*math.cos(angle)
        glow = np.exp(-(((x-cx)/.12)**2+((y-cy)/.12)**2)) + .24*np.exp(-(along/.34)**2-(across/.045)**2)
        strength = .90
    alpha = np.clip(glow * LIGHT_EFFECT_MAX_ALPHA * strength * profile['intensity'], 0, 255)
    rgb = np.zeros((sh, sw, 3), dtype='float32'); rgb[:] = np.asarray(color, dtype='float32')
    return Image.fromarray(np.dstack([np.clip(rgb, 0, 255), alpha]).astype('uint8'), 'RGBA').resize((w, h), Image.Resampling.BICUBIC)


def light_overlay(size, t, profile, alpha_scale=1.0):
    from PIL import Image
    elapsed = max(0.0, t); cycle_len = LIGHT_EFFECT_WINDOW + LIGHT_EFFECT_GAP
    cycle = int(elapsed // cycle_len); remaining = elapsed - cycle * cycle_len
    if cycle >= len(profile['events']) or remaining >= LIGHT_EFFECT_WINDOW:
        return None
    u = remaining / LIGHT_EFFECT_WINDOW; envelope = math.sin(math.pi * u) ** .72
    overlay = light_rgba(size, profile['events'][cycle], u, profile)
    overlay.putalpha(overlay.getchannel('A').point(lambda p: int(max(0, min(255, p * envelope * alpha_scale)))))
    return overlay


def masked(overlay, mask, scale=1.0):
    import numpy as np
    from PIL import Image
    if overlay is None:
        return None
    rgba = np.asarray(overlay).copy(); m = np.asarray(mask).astype('float32') / 255.0
    rgba[:, :, 3] = np.clip(rgba[:, :, 3].astype('float32') * m * scale, 0, 255).astype('uint8')
    return Image.fromarray(rgba, 'RGBA')


def outer_halo(mask, radius):
    """Return a soft outer aura that is later covered by the original text pixels."""
    from PIL import Image, ImageFilter
    radius = max(3, int(radius))
    # A small offset plus narrow blur is sufficient because the original glyphs
    # are composited later; it avoids a costly full-frame dilation per frame.
    result = Image.new('L', mask.size)
    offset = max(2, round(radius * .55))
    result.paste(mask, (0, offset))
    return result.filter(ImageFilter.GaussianBlur(max(2, round(radius * .24))))


def multi_light(background, fixed_text, body, t, profile):
    """Keep all generic white light below the supplied text pixels."""
    from PIL import Image
    import numpy as np
    result = background.convert('RGBA')
    ta = np.asarray(fixed_text.getchannel('A'), dtype='uint16')
    ba = np.asarray(body.getchannel('A'), dtype='uint16')
    union = np.maximum(ta, ba)
    bgmask = Image.fromarray((255 - union).astype('uint8'), 'L')
    # Background/global light is rendered below text and excluded from glyph pixels.
    ov = masked(light_overlay(background.size, t, profile, .95), bgmask, 1.0)
    if ov: result = Image.alpha_composite(result, ov)
    text_halo = outer_halo(Image.fromarray(union.astype('uint8'), 'L'), round(min(background.size) * .016))
    tov = masked(light_overlay(background.size, t, profile, .72), text_halo, .78)
    if tov: result = Image.alpha_composite(result, tov)
    gov = masked(light_overlay(background.size, t, profile, .36), bgmask, 1.0)
    if gov: result = Image.alpha_composite(result, gov)
    result = Image.alpha_composite(result, fixed_text)
    result = Image.alpha_composite(result, body)
    return result.convert('RGB')


def resolve_paths(job, job_path):
    for key in ('background', 'background_video', 'audio_source', 'video_audio_source', 'reference_video', 'work_dir', 'output_dir'):
        if job.get(key):
            job[key] = str((job_path.parent / Path(job[key])).resolve())
    layers = job.get('text_layers')
    if not isinstance(layers, list) or not layers:
        raise ValueError('text_layers must list at least one transparent page PNG')
    job['text_layers'] = [str((job_path.parent / Path(p)).resolve()) for p in layers]
    return job


def default_silent_sound(duration):
    count = max(1, int(round(duration * FPS))); duration = count / FPS
    return {'has_audio': False, 'path': None, 'source': None, 'selection': 'none',
            'fallback_chain': [], 'fallback_reason': 'no_readable_audio_source',
            'duration': duration, 'duration_ticks': int(round(duration * 30000)),
            'timescale': 30000, 'audio_duration': None, 'mux_offset': 0.0}


def validate_page_starts(starts, page_count, total_duration):
    if not isinstance(starts, list) or len(starts) != page_count:
        raise ValueError('page_starts must contain exactly one start time per body layer')
    values = [float(x) for x in starts]
    if (not all(math.isfinite(x) for x in values) or abs(values[0]) > 1e-6 or
            any(b <= a for a, b in zip(values, values[1:])) or values[-1] >= total_duration):
        raise ValueError('page_starts must start at 0, strictly increase, and begin before output end')
    return values


def infer_reference_page_starts(reference_video, title_box, page_count, output_duration, work):
    """Detect page changes from the reference's body region, then scale to output duration.

    The report is kept in the work directory for audit/review; it is never a delivery file.
    A confidence failure intentionally requires explicit page_starts instead of quietly using
    unrelated fixed timing when a reference video was supplied.
    """
    import numpy as np
    info = probe(reference_video)
    reference_duration = float(info.get('format', {}).get('duration', 0))
    if not math.isfinite(reference_duration) or reference_duration <= 0:
        raise ValueError('reference video has no valid duration for page timing')
    width, height, rate = 160, 284, 10
    raw = command(['ffmpeg', '-v', 'error', '-i', str(reference_video), '-an',
                   '-vf', f'fps={rate},scale={width}:{height}:flags=bicubic',
                   '-pix_fmt', 'gray', '-f', 'rawvideo', 'pipe:1'])
    one = width * height
    if len(raw) < one * 4:
        raise ValueError('reference video has too few decoded frames for page timing')
    frames = np.frombuffer(raw[:len(raw) // one * one], dtype=np.uint8).reshape((-1, height, width)).astype('float32')
    # Ignore the independently placed title band: only a lower body area may nominate a page turn.
    y0 = min(height - 8, max(4, int(float(title_box[3]) * height)))
    roi = frames[:, y0:height - 4, 6:width - 6]
    score = np.mean(np.abs(np.diff(roi, axis=0)), axis=(1, 2))
    smooth = np.convolve(score, np.array([.2, .6, .2]), mode='same')
    median = float(np.median(smooth)); mad = float(np.median(np.abs(smooth - median)))
    threshold = median + max(2.0, 5.0 * max(mad, .15))
    active = np.flatnonzero(smooth >= threshold)
    groups = []
    for index in active:
        if not groups or index > groups[-1][-1] + 2:
            groups.append([int(index)])
        else:
            groups[-1].append(int(index))
    candidates = []
    for group in groups:
        weights = smooth[group] - threshold + 1e-6
        stamp = float(np.average(np.asarray(group) + 1, weights=weights) / rate)
        strength = float(np.max(smooth[group]))
        if not candidates or stamp - candidates[-1]['time'] >= .65:
            candidates.append({'time': stamp, 'strength': strength})
        elif strength > candidates[-1]['strength']:
            candidates[-1] = {'time': stamp, 'strength': strength}
    report = {'reference_video': str(reference_video), 'reference_duration': reference_duration,
              'sample_fps': rate, 'body_roi': [6 / width, y0 / height, (width - 6) / width, (height - 4) / height],
              'threshold': threshold, 'median_score': median, 'mad_score': mad,
              'candidate_transitions': candidates, 'expected_transition_count': page_count - 1}
    if len(candidates) != page_count - 1:
        report.update({'status': 'needs_explicit_page_starts',
                       'reason': 'detected transition count does not match body layer count'})
        write_json(work / 'reference_page_timing.json', report)
        raise ValueError('Reference page turns were not confidently matched to body layers; inspect reference_page_timing.json and provide exact page_starts')
    scale = output_duration / reference_duration
    starts = [0.0] + [item['time'] * scale for item in candidates]
    starts = validate_page_starts(starts, page_count, output_duration)
    report.update({'status': 'detected', 'output_duration': output_duration,
                   'scale_to_output': scale, 'reference_page_starts': [0.0] + [item['time'] for item in candidates],
                   'output_page_starts': starts})
    write_json(work / 'reference_page_timing.json', report)
    return starts, report


def page_plan(page_count, page_duration, total_duration, has_audio, page_starts=None, lead_in=0.0):
    phase_duration = total_duration - lead_in
    if phase_duration <= 0:
        raise ValueError('The selected audio is too short to reveal title and any body page')
    if page_starts is not None:
        relative = validate_page_starts(page_starts, page_count, phase_duration)
        starts = [lead_in + t for t in relative]
        return {'page_count': page_count, 'requested_page_duration': page_duration,
                'page_starts': starts, 'page_starts_body_relative': relative, 'timing_source': 'explicit_page_starts',
                'planned_duration': total_duration, 'audio_controls_duration': bool(has_audio),
                'total_duration': total_duration, 'lead_in': lead_in, 'last_page_start': starts[-1]}
    planned = page_count * page_duration
    if has_audio:
        if phase_duration < planned and planned > 0:
            scale = phase_duration / planned
            segment = page_duration * scale
        else:
            segment = page_duration
    else:
        segment = page_duration
    relative = [i * segment for i in range(page_count)]
    starts = [lead_in + t for t in relative]
    return {'page_count': page_count, 'requested_page_duration': page_duration,
            'page_starts': starts, 'page_starts_body_relative': relative, 'timing_source': 'default_page_duration', 'segment_duration': segment, 'planned_duration': planned,
            'audio_controls_duration': bool(has_audio), 'total_duration': total_duration,
            'lead_in': lead_in, 'last_page_start': starts[-1]}


def render_multi(job, work, sound):
    from PIL import Image
    from watermark import Mark
    from audio_source import packet_timing
    background_source = prepare_background(job)
    background = background_source['preview']
    text_box = normalize_box(DEFAULT_TITLE_BOX, 'common_text_header_box')
    body_box = normalize_box(DEFAULT_BODY_BOX, 'common_text_body_box')
    raw_pages = [image(p) for p in job['text_layers']]
    for i, page in enumerate(raw_pages, 1):
        extrema = page.getchannel('A').getextrema()
        if extrema[1] == 0 or extrema[0] == 255:
            raise ValueError(f'text layer {i} must be a non-empty transparent PNG')
    fitted_texts = [fit_combined_text(page, background.size, f'text_{i:02d}')[0]
                    for i, page in enumerate(raw_pages, 1)]
    common_header, _ = split_combined_text(fitted_texts[0])
    header_bbox = visible_alpha_bbox(common_header)
    raw_bodies = [split_combined_text(page)[1] for page in fitted_texts]
    pages_and_layout = [fit_body(page, background.size, header_bbox, body_box, f'text_{i:02d}_body')
                        for i, page in enumerate(raw_bodies, 1)]
    pages = [item[0] for item in pages_and_layout]
    body_layout = [item[1] for item in pages_and_layout]
    # The first body page starts shortly after the fixed title; its actual
    # rows/cards then reveal in sequence while the background already breathes.
    first_body_delay = .35
    page_duration = float(job.get('page_duration', DEFAULT_PAGE_DURATION))
    if not math.isfinite(page_duration) or not 2.0 <= page_duration <= 8.0:
        raise ValueError('page_duration must be between 2 and 8 seconds')
    if sound['has_audio']:
        duration = float(sound['duration'])
    else:
        sound = default_silent_sound(len(pages) * page_duration)
        duration = sound['duration']
    explicit_starts = job.get('page_starts')
    timing_report = None
    if explicit_starts is not None:
        plan = page_plan(len(pages), page_duration, duration, sound['has_audio'], explicit_starts)
    elif job.get('reference_video') and Path(job['reference_video']).is_file():
        relative_starts, timing_report = infer_reference_page_starts(
            job['reference_video'], text_box, len(pages), duration, work)
        plan = page_plan(len(pages), page_duration, duration, sound['has_audio'], relative_starts)
        plan['timing_source'] = 'reference_video_detected'
        plan['reference_page_timing_report'] = str(work / 'reference_page_timing.json')
    else:
        plan = page_plan(len(pages), page_duration, duration, sound['has_audio'])
    starts = plan['page_starts']
    row_units = [infer_body_row_units(page) for page in pages]
    row_schedules = []
    for index, units in enumerate(row_units):
        reveal_start = starts[index] + (first_body_delay if index == 0 else 0.0)
        page_end = starts[index + 1] if index + 1 < len(starts) else duration
        row_schedules.append(body_row_schedule(units, reveal_start, page_end))
    row_audit = [audit_body_row_reveals(page, units, schedule)
                 for page, units, schedule in zip(pages, row_units, row_schedules)]
    end_background = background_at(background_source, max(0.0, duration - 1 / FPS))
    end_base = compose_layers(end_background, common_header, pages[-1])
    profile = light_effect_profile(end_base, duration)
    mark = Mark(job, background.width, background.height, 0.0, duration, work)
    count = ((sound['duration_ticks'] * FPS + sound['timescale'] - 1) // sound['timescale']) if sound['has_audio'] else int(round(duration * FPS))
    if count < max(3, len(pages) * 2):
        raise ValueError('Video is too short to display every body page')
    def frame_at(t, current_background=None):
        current_background = background_at(background_source, t) if current_background is None else current_background
        moving_background = breathe_background(current_background, t)
        current, previous, progress = page_state(t, pages, starts)
        body = sequential_body_rows(pages[current], row_units[current], row_schedules[current], t)
        if previous is not None:
            previous_body = sequential_body_rows(pages[previous], row_units[previous], row_schedules[previous], t)
            body = Image.alpha_composite(alpha_scaled(previous_body, 1.0 - progress),
                                         alpha_scaled(body, progress))
        # Only the background breathes.  Fixed header and body layers stay at their
        # fixed fitted positions throughout the complete animation.
        base = multi_light(moving_background, common_header, body, t, profile)
        return mark.apply(base, t)
    samples = work / 'samples'; samples.mkdir(exist_ok=True)
    for old in samples.glob('*.png'): old.unlink()
    sample_times = {0.0, first_body_delay, first_body_delay + PAGE_TRANSITION,
                    BREATH_PERIOD / 2, max(0.0, duration - 1 / FPS), duration - 0.2}
    for start in starts:
        sample_times.add(start)
        sample_times.add(min(duration - 1 / FPS, start + PAGE_TRANSITION / 2))
    for i, t in enumerate(sorted(x for x in sample_times if 0 <= x < duration)):
        frame_at(t).save(samples / f'{i:04d}.png')
    w, h = background.size; ew, eh = w + w % 2, h + h % 2
    target = work / 'final_animation.partial.mp4'
    args = ['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pixel_format', 'rgb24', '-video_size', f'{ew}x{eh}', '-framerate', str(FPS), '-i', 'pipe:0']
    if sound['has_audio']:
        args += ['-i', sound['path'], '-map', '0:v:0', '-map', '1:a:0', '-c:a', 'copy']
    else:
        args += ['-map', '0:v:0', '-an']
    args += ['-c:v', 'libx264', '-preset', job.get('preset', DEFAULT_PRESET), '-crf', str(job.get('crf', DEFAULT_CRF)),
             '-profile:v', VIDEO_PROFILE, '-level', VIDEO_LEVEL, '-maxrate', VIDEO_MAXRATE, '-bufsize', VIDEO_BUFSIZE,
             '-tune', 'stillimage', '-bf', '0', '-fps_mode', 'passthrough']
    if sound['has_audio']:
        last_pts = (count - 1) / FPS
        args += ['-bsf:v', packet_timing(sound, count, last_pts, cfr=True), '-video_track_timescale', str(sound['timescale']), '-movie_timescale', str(sound['timescale']), '-avoid_negative_ts', 'disabled']
    args += ['-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(target)]
    with open(work / 'encode.log', 'ab') as log:
        proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=log, stderr=log)
        source_proc = None
        background_repeated = False
        try:
            source_proc, background_repeated = open_background_reader(background_source, count, duration, log)
            for i in range(count):
                if source_proc is None:
                    source_frame = background
                else:
                    raw = source_proc.stdout.read(ew * eh * 3)
                    if len(raw) != ew * eh * 3:
                        raise RuntimeError('Looped background video ended before all planned output frames were decoded')
                    source_frame = Image.frombytes('RGB', (ew, eh), raw)
                proc.stdin.write(even_frame(frame_at(i / FPS, source_frame)).tobytes())
            proc.stdin.close()
            if proc.wait() != 0:
                raise RuntimeError((work / 'encode.log').read_text(errors='replace')[-2500:])
            if source_proc is not None:
                source_proc.stdout.close()
                if source_proc.wait() != 0:
                    raise RuntimeError((work / 'encode.log').read_text(errors='replace')[-2500:])
        except BaseException:
            if proc.poll() is None:
                proc.kill()
            proc.wait()
            if source_proc is not None:
                if source_proc.poll() is None:
                    source_proc.kill()
                source_proc.wait()
            raise
    background_report = {'kind': background_source['kind'], 'source': background_source['path'],
                         'canvas_size': list(background_source['canvas_size']),
                         'source_audio_used': False,
                         'loop_policy': background_source['loop_policy']}
    if background_source['kind'] == 'video':
        if background_repeated:
            policy = 'repeat_source_from_first_frame_in_original_order_then_trim_to_final_duration'
        elif duration < background_source['source_duration'] - 1e-9:
            policy = 'use_source_once_from_start_then_trim_excess_at_final_output_duration'
        else:
            policy = 'use_source_once_exactly_to_final_output_duration'
        background_report.update({'source_size': background_source['source_size'],
                                  'source_duration': background_source['source_duration'],
                                  'loop_policy': policy,
                                  'repeated': background_repeated,
                                  'output_duration': duration,
                                  'final_occurrence_trimmed_at_output_end': duration != background_source['source_duration']})
    return {'path': str(target), 'width': ew, 'height': eh, 'source_width': w, 'source_height': h,
            'frame_count': count, 'pts': [i / FPS for i in range(count)], 'duration': duration,
            'audio_count': int(sound['has_audio']), 'sound': sound, 'watermark': mark.report,
            'layout': {'background_canvas': list(background.size), 'background_source': background_report,
                       'common_header_box': list(text_box), 'common_header': {'source': 'text_01 upper zone',
                       'visible_box': normalized_bbox(header_bbox, background.size)},
                       'body_box': list(body_box), 'body_pages': body_layout,
                       'policy': 'extract_common_header_from_first_text_page_then_adapt_each_body_to_safe_zone'},
            'page_plan': {**plan, 'common_header_box': list(text_box), 'reference_timing_detected': bool(timing_report)},
            'common_header': {'source': 'text_01 upper zone', 'type': 'fixed_from_first_frame'},
            'light_effect': {'enabled': True, 'start': 0.0, 'window': LIGHT_EFFECT_WINDOW,
                'gap_after_end': LIGHT_EFFECT_GAP, 'cycle_duration': LIGHT_EFFECT_WINDOW + LIGHT_EFFECT_GAP,
                'event_count': len(profile['events']), 'randomized_per_event': True, 'family': profile['family'],
                'max_alpha': LIGHT_EFFECT_MAX_ALPHA, 'placement': 'generic-light-below-fixed-header-and-current-body; watermark-topmost'},
            'breathing': {'target': 'background_only', 'start': 0.0, 'period': BREATH_PERIOD,
                          'range': [1.0, 1.012, 1.0], 'max_scale': 1.012,
                          'header_and_body_fixed': True},
            'page_transition': {'duration': PAGE_TRANSITION, 'type': 'smooth_crossfade', 'page_count': len(pages)},
            'body_animation': {'type': 'sequential_visual_rows',
                               'pages': [{'page': i + 1, 'row_count': len(units),
                                          'row_units': [{'y0': a, 'y1': b} for a, b in units],
                                          'schedule': audit}
                                         for i, (units, audit) in enumerate(zip(row_units, row_audit))]}}


def verify_movie(path, expected, work):
    info = probe(path); detailed = probe(path, True); v = video_stream(info); pts = frame_times(detailed)
    if v['codec_name'] != 'h264' or (v['width'], v['height']) != (expected['width'], expected['height']):
        raise ValueError('Output codec or dimensions differ from plan')
    if len(pts) != expected['frame_count']:
        raise ValueError(f'Frame count mismatch: {len(pts)} / {expected["frame_count"]}')
    tick = float(Fraction(v['time_base'])); err = max(abs(a - b) for a, b in zip(pts, expected['pts']))
    if err > tick + 2e-6: raise ValueError(f'Presentation timestamps changed: max {err}s / tick {tick}s')
    if abs(float(v['duration']) - expected['duration']) > max(tick * 2, 2e-5):
        raise ValueError(f'Duration changed: {v["duration"]} / {expected["duration"]}')
    audio = [s for s in info['streams'] if s['codec_type'] == 'audio']
    if len(audio) != expected['audio_count']: raise ValueError('Audio tracks missing or added')
    sound = expected.get('sound')
    if sound and sound['has_audio']:
        a = audio[0]; tolerance = max(2 / sound['sample_rate'], 2e-6)
        if a['channels'] != sound['channels'] or int(a['sample_rate']) != sound['sample_rate']:
            raise ValueError('Source audio channels or sample rate changed')
        if abs(float(a['duration']) - sound['audio_duration']) > tolerance:
            raise ValueError(f'Audio duration changed: {a["duration"]} / {sound["audio_duration"]}')
    if v.get('r_frame_rate') != '30/1': raise ValueError('Output frame rate is not 30 fps')
    command(['ffmpeg', '-v', 'error', '-xerror', '-i', str(path), '-map', '0:v:0', '-map', '0:a?', '-f', 'null', '-'], work / 'decode.log')
    return {'engine_version': VERSION, 'codec': 'h264', 'width': v['width'], 'height': v['height'], 'frames': len(pts),
            'duration': float(v['duration']), 'max_pts_error': err, 'audio_tracks': len(audio), 'full_decode': 'passed',
            'sound': sound, 'watermark': expected.get('watermark'), 'page_plan': expected.get('page_plan'),
            'page_transition': expected.get('page_transition'), 'breathing': expected.get('breathing'),
            'light_effect': expected.get('light_effect'), 'layout': expected.get('layout'),
            'common_header': expected.get('common_header')}


def package_movie(movie, out):
    out = Path(out); out.mkdir(parents=True, exist_ok=True); movie = Path(movie); expected_hash = digest(movie)
    ztemp = out / 'MP4.partial.zip'
    with zipfile.ZipFile(ztemp, 'w', zipfile.ZIP_STORED) as z: z.write(movie, 'final_animation.mp4')
    with zipfile.ZipFile(ztemp) as z:
        if z.namelist() != ['final_animation.mp4']: raise ValueError('Delivery ZIP must contain only final_animation.mp4')
    ztemp.replace(out / 'MP4.zip')
    return {'zip': str(out / 'MP4.zip'), 'mp4_sha256': expected_hash, 'mp4_bytes': movie.stat().st_size}


def run_job(job_path):
    import audio_source, watermark
    status = check_environment()
    if not status['ready']: raise RuntimeError(f'Missing dependencies: {status["missing"]}')
    job_path = Path(job_path).resolve(); job = resolve_paths(json.loads(job_path.read_text(encoding='utf-8')), job_path)
    if job.get('mode') != 'MULTI_PAGE': raise ValueError('mode must be MULTI_PAGE')
    if bool(job.get('background')) == bool(job.get('background_video')):
        raise ValueError('Provide exactly one background input: background image or background_video')
    if not job.get('text_layers'):
        raise ValueError('Missing required input: text_layers')
    allowed = {'mode','background','background_video','text_layers','page_duration','page_starts','work_dir','output_dir','crf','preset','watermark','audio_source','video_audio_source','reference_video','audio_stream'}
    if set(job) - allowed: raise ValueError(f'Unsupported parameters: {sorted(set(job)-allowed)}')
    for key in ('background','background_video','audio_source','video_audio_source','reference_video','work_dir','output_dir'):
        if job.get(key) and key not in ('work_dir','output_dir') and not Path(job[key]).is_file():
            if key in ('audio_source','video_audio_source','reference_video'): job[key] = str(job[key])
            else: raise FileNotFoundError(job[key])
    for p in job['text_layers']:
        if not Path(p).is_file(): raise FileNotFoundError(p)
    work = Path(job.get('work_dir', job_path.parent / 'work')); work.mkdir(parents=True, exist_ok=True)
    out = Path(job.get('output_dir', job_path.parent / 'delivery'))
    input_keys = [key for key in ('background', 'background_video') if job.get(key)] + ['text_layers']
    inputs = {k: [digest(p) for p in job[k]] if k == 'text_layers' else digest(job[k]) for k in input_keys}
    for k in ('audio_source','video_audio_source','reference_video'):
        if job.get(k): inputs[k] = digest(job[k]) if Path(job[k]).is_file() else 'UNAVAILABLE'
    render_job = {k:v for k,v in job.items() if k not in ('output_dir','work_dir')}
    fp = hashlib.sha256(json.dumps({'job':render_job,'inputs':inputs,'engine':digest(__file__),
        'watermark_engine':watermark.fingerprint(job),'audio_engine':digest(audio_source.__file__)}, sort_keys=True).encode()).hexdigest()
    state_file = work / 'job_state.json'; state = json.loads(state_file.read_text()) if state_file.exists() else {}
    final = work / 'final_animation.mp4'; start = time.monotonic()
    if state.get('fingerprint') == fp and state.get('movie_verified') and final.exists() and state.get('mp4_sha256') == digest(final):
        result = state['movie_verified']
    else:
        write_json(state_file, {'fingerprint':fp, 'stage':'rendering', 'inputs':inputs, 'engine_version':VERSION})
        sound = audio_source.prepare(job, work, probe, command)
        expected = render_multi(job, work, sound)
        result = verify_movie(expected['path'], expected, work)
        Path(expected['path']).replace(final)
        state = {'fingerprint':fp, 'stage':'video_verified', 'inputs':inputs, 'engine_version':VERSION,
                 'movie_verified':result, 'mp4_sha256':digest(final)}
        write_json(state_file, state)
    packaged = package_movie(final, out)
    state.update({'stage':'packaged','delivery':packaged,'elapsed_this_run_seconds':round(time.monotonic()-start,3),
                  'visual_review':'inspect samples before claiming complete'})
    write_json(state_file, state)
    return {**result, **packaged, 'state':str(state_file), 'elapsed_seconds':state['elapsed_this_run_seconds']}


def main():
    parser = argparse.ArgumentParser(description=__doc__); subs = parser.add_subparsers(dest='command', required=True)
    subs.add_parser('doctor'); run = subs.add_parser('run'); run.add_argument('job')
    p = subs.add_parser('package'); p.add_argument('--movie', required=True); p.add_argument('--out', required=True)
    args = parser.parse_args()
    try:
        if args.command == 'doctor': result = check_environment()
        elif args.command == 'run': result = run_job(args.job)
        else: result = package_movie(args.movie, args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.command == 'doctor' and not result['ready']: sys.exit(2)
    except Exception as exc:
        print(json.dumps({'error':str(exc), 'command':args.command}, ensure_ascii=False), file=sys.stderr); sys.exit(1)


if __name__ == '__main__': main()
