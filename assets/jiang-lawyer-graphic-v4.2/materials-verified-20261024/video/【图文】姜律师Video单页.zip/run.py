#!/usr/bin/env python3
"""Portable entry point; uses only this package and the current Python runtime."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))

def main():
    import video_engine
    if sys.argv[1:] != ['doctor']:
        video_engine.main()
        return
    try:
        report = video_engine.check_environment()
        report.pop('browser_required', None)
        report.pop('network_required', None)
        issues = []
        manifest = json.loads((ROOT / 'bundle.json').read_text(encoding='utf-8'))
        for name, expected in manifest['sha256'].items():
            p = ROOT / name
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != expected:
                issues.append(name)
        report['bundle_files_ok'] = not issues
        report['bundle_file_issues'] = issues
        if report['ready']:
            import numpy
            from PIL import ImageFont
            ImageFont.truetype(str(ROOT / 'assets/fonts/SystemAWatermark-Bold.otf'), 32)
        report['ready'] = report['ready'] and not issues
        print(json.dumps(report, ensure_ascii=False, indent=2))
        if not report['ready']:
            sys.exit(2)
    except Exception as exc:
        print(json.dumps({'ready': False, 'error': str(exc)}, ensure_ascii=False))
        sys.exit(2)

if __name__ == '__main__':
    main()
