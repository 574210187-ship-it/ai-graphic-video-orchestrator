"""Shared full-frame brand overlay for single-poster video jobs."""
from pathlib import Path
import hashlib
import json
import math
from PIL import Image, ImageDraw, ImageFont

FONT = Path(__file__).resolve().parent.parent/'assets/fonts/SystemAWatermark-Bold.otf'
TEXT = '盐城姜律师'


def config(job):
    value = job.get('watermark', {})
    if value is False:
        return {'enabled':False}
    if not isinstance(value,dict) or set(value)-{'enabled','opacity','width_fraction','period'}:
        raise ValueError('watermark accepts enabled, opacity, width_fraction and period')
    result={'enabled':True,'opacity':.08,'width_fraction':.20,'period':12.,**value}
    if not isinstance(result['enabled'],bool):
        raise ValueError('watermark.enabled must be boolean')
    for key,lo,hi in [('opacity',.08,.8),('width_fraction',.15,.80),('period',1.,12.)]:
        number=float(result[key])
        if not math.isfinite(number) or not lo<=number<=hi:
            raise ValueError('Invalid watermark '+key)
        result[key]=number
    return result


def fingerprint(job):
    cfg=config(job)
    return hashlib.sha256(Path(__file__).read_bytes()+(FONT.read_bytes() if cfg['enabled'] else b'')).hexdigest()


class Mark:
    def __init__(self,job,w,h,start,end,work):
        self.cfg=config(job); self.w=w; self.h=h; self.start=start; self.end=end
        self.period=self.cfg.get('period',12.)
        self.enabled=self.cfg['enabled'] and end>start
        self.sprite=None
        if self.enabled:
            # Reuse the compact bold glyph sprite throughout the video.
            # Supersample only this small reusable sprite, never the video frames.
            ss=4; font=ImageFont.truetype(str(FONT),54*ss)
            sprite=Image.new('RGBA',(400*ss,100*ss)); draw=ImageDraw.Draw(sprite)
            x=8*ss
            for char in TEXT:
                draw.text((x,8*ss),char,font=font,
                    fill=(255,255,255,round(255*self.cfg['opacity'])),stroke_width=ss,
                    stroke_fill=(12,24,40,round(255*min(.65,self.cfg['opacity']+.10))))
                x+=draw.textlength(char,font=font)+2*ss
            limit=max(1,round(w*self.cfg['width_fraction']))
            height=max(1,min(h,round(limit*47/286)))
            sprite=sprite.crop(sprite.getbbox()).resize((limit,height),Image.Resampling.LANCZOS)
            self.sprite=sprite
            self.x0=min(round(w*.028),max(0,(w-sprite.width)//2))
            self.y0=min(round(h*.023),max(0,(h-sprite.height)//2))
            self.dx=max(0,w-self.x0*2-sprite.width)
            self.dy=max(0,h-self.y0*2-sprite.height)
            # Per-job phases, generated once; no frame-by-frame randomness/jitter.
            source=job.get('final') or job.get('background') or job.get('background_video') or job.get('title_layer','')
            seed=hashlib.sha256(str(source).encode()).digest()
            self.phases=[int.from_bytes(seed[i:i+2],'big')/65535*2*math.pi for i in (0,2,4,6)]
            sprite.save(work/'watermark.png')
        self.report={'enabled':self.enabled,'text':TEXT,'start':start,'end':end,
                     'region':'full_frame','motion':'smooth_irregular_wander',
                     'opacity':self.cfg.get('opacity'),
                     'width_fraction':self.cfg.get('width_fraction'),'period':self.period,
                     'sprite_size':list(self.sprite.size) if self.sprite else None,
                     'tracking_em':2/54}
        (work/'watermark_plan.json').write_text(json.dumps(self.report,ensure_ascii=False,indent=2))

    def position(self,t):
        phase=2*math.pi*(t-self.start)/self.period
        a,b,c,d=self.phases
        x=.5+.36*math.sin(phase+a)+.14*math.sin(math.sqrt(2)*phase+b)
        y=.5+.36*math.sin(math.sqrt(1.3)*phase+c)+.14*math.sin(math.sqrt(3)*phase+d)
        return (round(self.x0+self.dx*x),round(self.y0+self.dy*y))

    def apply(self,frame,t):
        if not self.enabled or t<self.start or t>=self.end:
            return frame
        result=frame.convert('RGBA')
        result.alpha_composite(self.sprite,self.position(t))
        return result.convert('RGB')

    def ffmpeg_overlay(self,input_index,clock_offset=0):
        start=self.start+clock_offset
        phase=f'2*PI*(t-{start:.12g})/{self.period:.12g}'
        a,b,c,d=self.phases
        x=f'round({self.x0}+{self.dx}*(0.5+0.36*sin({phase}+{a:.15g})+0.14*sin(sqrt(2)*({phase})+{b:.15g})))'
        y=f'round({self.y0}+{self.dy}*(0.5+0.36*sin(sqrt(1.3)*({phase})+{c:.15g})+0.14*sin(sqrt(3)*({phase})+{d:.15g})))'
        end=self.end+clock_offset
        return (f'[without_watermark][{input_index}:v]overlay=x=\'{x}\':y=\'{y}\':'
                f'enable=\'gte(t,{start:.12g})*lt(t,{end:.12g})\':eval=frame:shortest=1:format=rgb,'
                'format=yuv420p[out]')
