#!/usr/bin/env python3
"""System A deterministic rendering. No browser, web server or network required."""
import argparse
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

VERSION = '5.1.1-single-text-layer-no-light-effects'
FPS = 30
BREATH_PERIOD = 4.0
TITLE_REVEAL_MAX = 0.8
MIN_ANIMATION_DURATION = 2.4
MAX_ANIMATION_DURATION = 3.8
TRANSITION_DURATION = 0.35
ROW_ALPHA_THRESHOLD = 24
ROW_SCORE_MIN = 6.0
# Image-led vertical posters do not need unconstrained CRF-18 bitrate.  Keep
# the default visually clean while putting a hard ceiling on short-video size.
DEFAULT_CRF = 20
DEFAULT_PRESET = 'medium'
VIDEO_PROFILE = 'high'
VIDEO_LEVEL = '5.2'
VIDEO_MAXRATE = '10M'
VIDEO_BUFSIZE = '20M'
DEFAULT_TITLE_BOX = (.08, .06, .92, .28)
DEFAULT_BODY_BOX = (.10, .28, .90, .91)
TITLE_BODY_GAP_TARGET = .055
TITLE_BODY_GAP_MIN = .04
TITLE_BODY_GAP_MAX = .07
MIN_BODY_SCALE = .80
ALPHA_LAYOUT_THRESHOLD = 16


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for part in iter(lambda: f.read(1048576), b''):
            h.update(part)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.partial')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def command(args, log=None):
    if log:
        with open(log, 'ab') as stream:
            result = subprocess.run(args, stdout=stream, stderr=stream)
        if result.returncode:
            tail = Path(log).read_text(errors='replace')[-3000:]
            raise RuntimeError(f'Command failed ({result.returncode}): {tail}')
        return None
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace')[-3000:])
    return result.stdout


def probe(path, frames=False):
    args = ['ffprobe', '-v', 'error', '-show_streams', '-show_format']
    if frames:
        args += ['-select_streams', 'v:0', '-show_frames', '-show_entries',
                 'frame=best_effort_timestamp_time,pts_time,pkt_duration_time,duration_time']
    args += ['-of', 'json', str(path)]
    return json.loads(command(args))


def video_stream(info):
    return next(s for s in info['streams'] if s['codec_type'] == 'video')


def frame_times(info):
    return [float(f.get('best_effort_timestamp_time', f.get('pts_time')))
            for f in info['frames']]


def check_environment():
    import importlib.util
    missing = [x for x in ('ffmpeg', 'ffprobe') if not shutil.which(x)]
    missing += [x for x in ('PIL', 'numpy') if importlib.util.find_spec(x) is None]
    enc = command(['ffmpeg', '-hide_banner', '-encoders']).decode() if not missing else ''
    if not missing and 'libx264' not in enc:
        missing.append('FFmpeg libx264 encoder')
    if not missing and ' aac ' not in enc:
        missing.append('FFmpeg AAC encoder')
    return {'engine_version': VERSION, 'ready': not missing, 'missing': missing,
            'browser_required': False, 'network_required': False}


def image(path, mode='RGBA'):
    from PIL import Image, ImageOps
    im = Image.open(path)
    if im.info.get('icc_profile'):
        raise ValueError(f'ICC profile needs explicit sRGB normalization first: {path}')
    im = ImageOps.exif_transpose(im)
    if im.mode in ('I', 'F') or im.mode.startswith('I;16'):
        raise ValueError('Normalize high-bit-depth input explicitly before rendering')
    im = im.convert('RGBA')
    if mode == 'RGB' and im.getchannel('A').getextrema() != (255, 255):
        raise ValueError(f'Opaque background/final required: {path}')
    return im.convert(mode)


def positive_video_duration(info, stream, path):
    for value in (info.get('format', {}).get('duration'), stream.get('duration')):
        try:
            duration = float(value)
        except (TypeError, ValueError):
            continue
        if math.isfinite(duration) and duration > 0:
            return duration
    raise ValueError(f'background_video must have a finite positive duration: {path}')


def video_background_frame(source, t):
    """Read a review/profile frame at t modulo the source duration."""
    from PIL import Image
    local_t = max(0.0, float(t)) % source['source_duration']
    w, h = source['canvas_size']
    raw = command(['ffmpeg', '-v', 'error', '-ss', f'{local_t:.9f}', '-i', source['path'],
                   '-map', '0:v:0', '-an', '-frames:v', '1',
                   '-vf', f'scale={w}:{h}:flags=lanczos', '-pix_fmt', 'rgb24',
                   '-f', 'rawvideo', 'pipe:1'])
    if len(raw) != w * h * 3:
        raise ValueError(f'Could not decode a full background-video frame at {local_t:.3f}s')
    return Image.frombytes('RGB', (w, h), raw)


def prepare_video_background(job, seed_material):
    """Use an explicit attachment when provided, else pick one bundled blue loop."""
    explicit = job.get('background_video')
    if explicit:
        path = Path(explicit)
        choice = 'explicit_background_video'
    else:
        options = sorted((Path(__file__).resolve().parent.parent / 'assets' / 'backgrounds').glob('*.mp4'))
        if not options:
            raise ValueError('No bundled blue background video is available')
        index = int(hashlib.sha256(seed_material).hexdigest()[:16], 16) % len(options)
        path = options[index]
        choice = 'bundled_blue_background_selected_deterministically'
    if not path.is_file():
        raise FileNotFoundError(path)
    info = probe(path)
    try:
        stream = video_stream(info)
    except StopIteration as exc:
        raise ValueError(f'background_video has no readable video stream: {path}') from exc
    width, height = int(stream.get('width', 0)), int(stream.get('height', 0))
    if width < 2 or height < 2:
        raise ValueError(f'background_video has invalid dimensions: {path}')
    source = {'path': str(path), 'source_name': path.name, 'selection': choice,
              'source_duration': positive_video_duration(info, stream, path),
              'source_size': [width, height],
              'canvas_size': (width + width % 2, height + height % 2),
              'source_audio_used': False}
    source['preview'] = video_background_frame(source, 0.0)
    return source


def open_video_background_reader(source, frame_count, output_duration, log):
    """Use one pass when enough; otherwise loop source order until output end."""
    repeat = output_duration > source['source_duration'] + 1e-9
    w, h = source['canvas_size']
    args = ['ffmpeg', '-v', 'error']
    if repeat:
        args += ['-stream_loop', '-1']
    args += ['-i', source['path'], '-map', '0:v:0', '-an',
             '-vf', f'fps={FPS},scale={w}:{h}:flags=lanczos',
             '-frames:v', str(frame_count), '-pix_fmt', 'rgb24', '-f', 'rawvideo', 'pipe:1']
    return subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=log), repeat


def normalize_box(box, name):
    if not isinstance(box, (list, tuple)) or len(box) != 4:
        raise ValueError(f'{name} must be [x0,y0,x1,y1] normalized to 0..1')
    x0, y0, x1, y1 = [float(v) for v in box]
    if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
        raise ValueError(f'{name} must be ordered normalized coordinates within 0..1')
    return x0, y0, x1, y1


def visible_alpha_bbox(layer, threshold=ALPHA_LAYOUT_THRESHOLD):
    alpha = layer.getchannel('A')
    bbox = alpha.point(lambda p: 255 if p >= threshold else 0).getbbox()
    if not bbox:
        raise ValueError('transparent layer has no visible artwork above layout threshold')
    return bbox


def normalized_bbox(bbox, size):
    x0, y0, x1, y1 = bbox; w, h = size
    return [x0 / w, y0 / h, x1 / w, y1 / h]


def crop_visible(layer, label):
    bbox = visible_alpha_bbox(layer)
    crop = layer.crop(bbox)
    if crop.width < 2 or crop.height < 2:
        raise ValueError(f'{label} has no usable visible area')
    return crop, bbox


def place_crop(crop, canvas_size, x, y, scale):
    from PIL import Image
    nw, nh = max(1, round(crop.width * scale)), max(1, round(crop.height * scale))
    out = Image.new('RGBA', canvas_size)
    out.alpha_composite(crop.resize((nw, nh), Image.Resampling.LANCZOS), (round(x), round(y)))
    return out


def fit_title(layer, canvas_size, title_box):
    crop, source_bbox = crop_visible(layer, 'title_layer')
    cw, ch = canvas_size; x0, y0, x1, y1 = normalize_box(title_box, 'title_box')
    available_w, available_h = (x1 - x0) * cw, (y1 - y0) * ch
    scale = min(available_w * .95 / crop.width, available_h / crop.height)
    out = place_crop(crop, canvas_size, (cw - crop.width * scale) / 2, y0 * ch, scale)
    bbox = visible_alpha_bbox(out)
    return out, {'source_visible_box': normalized_bbox(source_bbox, layer.size),
                 'visible_box': normalized_bbox(bbox, canvas_size), 'scale': scale,
                 'target_box': [x0, y0, x1, y1]}


def fit_body(layer, canvas_size, title_bbox, body_box):
    crop, source_bbox = crop_visible(layer, 'body_layer')
    cw, ch = canvas_size; x0, _, x1, y1 = normalize_box(body_box, 'body_box')
    title_bottom = title_bbox[3]
    body_top = title_bottom + round(ch * TITLE_BODY_GAP_TARGET)
    body_bottom = round(y1 * ch)
    available_w, available_h = (x1 - x0) * cw, body_bottom - body_top
    if available_h <= 0:
        raise ValueError('body_layer has no safe area below title')
    scale = min(available_w * .975 / crop.width, available_h / crop.height)
    if scale < MIN_BODY_SCALE:
        raise ValueError(f'body_layer is too dense for the safe area (scale {scale:.3f} < {MIN_BODY_SCALE:.2f}); split content before rendering')
    out = place_crop(crop, canvas_size, (cw - crop.width * scale) / 2, body_top, scale)
    bbox = visible_alpha_bbox(out); gap = bbox[1] - title_bottom
    if not round(ch * TITLE_BODY_GAP_MIN) <= gap <= round(ch * TITLE_BODY_GAP_MAX):
        raise ValueError('title/body gap violates the 4%–7% canvas-height rule')
    return out, {'source_visible_box': normalized_bbox(source_bbox, layer.size),
                 'visible_box': normalized_bbox(bbox, canvas_size), 'scale': scale,
                 'target_box': [x0, body_top / ch, x1, y1],
                 'title_body_gap_px': gap, 'title_body_gap_fraction': gap / ch}


def compare(a, b):
    import numpy as np
    x, y = np.asarray(a).astype('int16'), np.asarray(b).astype('int16')
    if x.shape != y.shape:
        raise ValueError(f'Different shapes: {x.shape} / {y.shape}')
    diff = np.abs(x - y)
    return {'different_pixels': int(np.any(diff != 0, axis=2).sum()),
            'max_channel_error': int(diff.max())}


def validate_bounds(bounds, height):
    if (not isinstance(bounds, list) or len(bounds) < 2 or bounds[0] != 0 or
        bounds[-1] != height or any(type(x) is not int for x in bounds) or
        any(a >= b for a, b in zip(bounds, bounds[1:]))):
        raise ValueError('bounds must be increasing integers from 0 to complete PNG height')


def infer_title_height(foreground, supplied=0, supplied_bounds=None):
    """Infer title cutoff when the caller leaves the old 0 placeholder."""
    import numpy as np
    h = foreground.height
    if isinstance(supplied, int) and supplied > 0:
        return min(supplied, h - 1)
    alpha = np.asarray(foreground.getchannel('A'))
    active = np.max(alpha, axis=1) > 8
    runs = []
    start = None
    for i, on in enumerate(active):
        if on and start is None:
            start = i
        elif not on and start is not None:
            runs.append((start, i))
            start = None
    if start is not None:
        runs.append((start, h))
    gap_min = max(8, h // 300)
    if len(runs) >= 2:
        end = runs[0][1]
        for start, stop in runs[1:]:
            if start - end >= gap_min:
                return max(1, min(start, h - 1))
            end = stop
    if isinstance(supplied_bounds, list) and len(supplied_bounds) > 1:
        candidate = supplied_bounds[1]
        if isinstance(candidate, int) and 1 < candidate < h:
            return candidate
    return max(1, min(h - 1, round(h * 0.12)))


def _runs(active, minimum=2, merge_gap=0):
    runs = []
    start = None
    for i, on in enumerate(active):
        if on and start is None:
            start = i
        elif not on and start is not None:
            if i - start >= minimum:
                runs.append((start, i))
            start = None
    if start is not None and len(active) - start >= minimum:
        runs.append((start, len(active)))
    if merge_gap <= 0 or not runs:
        return runs
    merged = [runs[0]]
    for start, stop in runs[1:]:
        if start - merged[-1][1] <= merge_gap:
            merged[-1] = (merged[-1][0], stop)
        else:
            merged.append((start, stop))
    return merged


def _visual_row_runs(foreground, title_height):
    """Find visible text bands even when a translucent panel joins all Alpha rows.

    Alpha-only runs fail on common posters because the panel/background rectangle
    is one continuous foreground region.  A smoothed luminance-edge projection
    finds the repeated horizontal text bands without altering source pixels.
    """
    import numpy as np
    rgba = np.asarray(foreground).astype('float32')
    rgb = rgba[:, :, :3]
    alpha = rgba[:, :, 3]
    gray = 0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2]
    gx = np.abs(gray[:, 1:] - gray[:, :-1]).mean(axis=1)
    gy = np.abs(gray[1:, :] - gray[:-1, :]).mean(axis=1)
    score = np.zeros(gray.shape[0], dtype='float32')
    score[1:-1] = gx[1:-1] + np.maximum(gy[:-1], gy[1:])
    smooth_window = max(5, min(15, foreground.height // 180))
    score = np.convolve(score, np.ones(smooth_window, dtype='float32') / smooth_window, mode='same')
    score[:title_height] = 0
    score[alpha.max(axis=1) <= ROW_ALPHA_THRESHOLD] = 0
    body = score[title_height:]
    if not np.any(body > ROW_SCORE_MIN):
        return []
    threshold = max(ROW_SCORE_MIN, float(np.percentile(body[body > 0], 55)) * 0.8)
    active = score >= threshold
    runs = _runs(active, minimum=max(3, foreground.height // 800), merge_gap=max(3, foreground.height // 500))
    return [(max(title_height, a), min(foreground.height, b))
            for a, b in runs if b > title_height and b - max(title_height, a) >= 3]


def infer_row_units(foreground, title_height, supplied=None, supplied_bounds=None):
    """Return explicit (y0, y1) body units for true sequential compositing."""
    import numpy as np
    h = foreground.height
    if isinstance(supplied, list) and supplied:
        units = []
        for item in supplied:
            if isinstance(item, dict):
                a, b = item.get('y0'), item.get('y1')
            elif isinstance(item, (list, tuple)) and len(item) == 2:
                a, b = item
            else:
                raise ValueError('line_units must contain {y0,y1} pairs')
            if type(a) is not int or type(b) is not int or not (title_height <= a < b <= h):
                raise ValueError('line_units contain invalid coordinates')
            if units and units[-1][1] > a:
                raise ValueError('line_units must be ordered and non-overlapping')
            units.append((a, b))
        if units:
            return units
    # Backward-compatible explicit bounds are converted into independent bands.
    if isinstance(supplied_bounds, list) and len(supplied_bounds) >= 2:
        try:
            validate_bounds(supplied_bounds, h)
            body_bounds = [title_height] + [b for b in supplied_bounds if b > title_height]
            if body_bounds[-1] != h:
                body_bounds.append(h)
            units = [(a, b) for a, b in zip(body_bounds, body_bounds[1:]) if b - a >= 3]
            if len(units) > 1:
                return units
        except ValueError:
            pass
    alpha = np.asarray(foreground.getchannel('A'))
    active = np.max(alpha, axis=1) > ROW_ALPHA_THRESHOLD
    alpha_runs = _runs(active, minimum=max(2, h // 800), merge_gap=max(3, h // 500))
    body_runs = [(max(title_height, a), min(h, b)) for a, b in alpha_runs
                 if b > title_height and b - max(title_height, a) >= 3]
    # The panel often creates one huge Alpha run.  Use actual visual text bands
    # whenever an Alpha run spans a substantial part of the body; otherwise a
    # full poster panel would be mistaken for one animation row.
    if len(body_runs) > 1 and not any((b - a) > max(300, int(h * 0.24)) for a, b in body_runs):
        return body_runs
    visual = _visual_row_runs(foreground, title_height)
    if len(visual) > 1:
        return visual
    if body_runs:
        return body_runs
    return [(title_height, h)]


def animation_duration(row_units, title_height):
    steps = max(1, len(row_units))
    return min(MAX_ANIMATION_DURATION, max(MIN_ANIMATION_DURATION, 0.65 + 0.25 * steps))


def title_reveal_progress(t, duration):
    """Continuous title entrance: hidden on the first frame, complete early."""
    u = max(0.0, min(1.0, t / duration)) if duration > 0 else 1.0
    return u*u*(3.0-2.0*u)


def _smoothstep(u):
    u = max(0.0, min(1.0, float(u)))
    return u * u * (3.0 - 2.0 * u)


def row_schedule(row_units, body_start, animation_end):
    """Reserve the final crossfade; every independent row settles before it."""
    if len(row_units) < 1:
        raise ValueError('ROW_AUDIT_FAIL: no body line units')
    reveal_end = animation_end - TRANSITION_DURATION
    if reveal_end <= body_start:
        raise ValueError('No time remains for body rows before final transition')
    step = (reveal_end - body_start) / len(row_units)
    window = min(0.34, step * 0.90)
    return [(body_start + i * step, body_start + i * step + window)
            for i in range(len(row_units))]


def row_bands(row_units, title_height, height):
    """Assign panel/gap pixels to neighboring rows without color classification."""
    if not row_units or any(not (title_height <= a < b <= height) for a, b in row_units):
        raise ValueError('line_units contain invalid coordinates')
    if any(b > c for (_, b), (c, _) in zip(row_units, row_units[1:])):
        raise ValueError('line_units must be ordered and non-overlapping')
    cuts = [title_height]
    cuts += [(b + c) // 2 for (_, b), (c, _) in zip(row_units, row_units[1:])]
    cuts += [height]
    return list(zip(cuts, cuts[1:]))


def sequential_foreground(foreground, t, title_height, title_end,
                          row_units, body_start, animation_end):
    """Fade/move each full RGBA row, preserving black ink and all source colors."""
    import numpy as np
    from PIL import Image
    if body_start < title_end:
        raise ValueError('Body must start after the title is fully visible')
    src = np.asarray(foreground)
    out = src.copy()
    out[:, :, 3] = 0

    def reveal(y0, y1, progress):
        unit = src[y0:y1].copy()
        unit[:, :, 3] = np.rint(unit[:, :, 3] * progress).astype('uint8')
        # At most two pixels of horizontal entrance, bounded by actual margins.
        # Settled units restore exact source RGBA; no permanent re-layout.
        columns = np.flatnonzero(src[y0:y1, :, 3].max(axis=0))
        room = src.shape[1] - 1 - int(columns[-1]) if columns.size else 0
        dx = round(min(2, room) * (1.0 - progress))
        if dx:
            out[y0:y1, dx:] = unit[:, :-dx]
        else:
            out[y0:y1] = unit

    title_progress = _smoothstep(t / title_end) if title_end > 0 else 1.0
    reveal(0, title_height, title_progress)
    bands = row_bands(row_units, title_height, foreground.height)
    for (y0, y1), (start, end) in zip(bands, row_schedule(row_units, body_start, animation_end)):
        reveal(y0, y1, _smoothstep((t - start) / (end - start)))
    return Image.fromarray(out)


def audit_row_timing(foreground, title_height, title_end, row_units,
                     body_start, animation_end):
    """Check all RGBA pixels, not only bright ink, before allowing encoding."""
    import numpy as np
    src = np.asarray(foreground)
    bands = row_bands(row_units, title_height, foreground.height)
    schedule = row_schedule(row_units, body_start, animation_end)
    def frame(t):
        return np.asarray(sequential_foreground(
            foreground, t, title_height, title_end, row_units, body_start, animation_end))
    if frame(0)[:, :, 3].any():
        raise ValueError('ROW_AUDIT_FAIL: foreground visible on first frame')
    at_title = frame(title_end)
    if not np.array_equal(at_title[:title_height], src[:title_height]):
        raise ValueError('ROW_AUDIT_FAIL: title colors or pixels changed')
    if at_title[title_height:, :, 3].any():
        raise ValueError('ROW_AUDIT_FAIL: body visible before title completes')
    checks = []
    for i, ((y0, y1), (start, end)) in enumerate(zip(bands, schedule)):
        if not src[y0:y1, :, 3].any():
            raise ValueError(f'ROW_AUDIT_FAIL: empty line {i + 1}')
        before = frame(max(0, start - 1e-6))
        during = frame((start + end) / 2)
        after = frame(end + 1e-6)
        if before[y0:y1, :, 3].any():
            raise ValueError(f'ROW_AUDIT_FAIL: line {i + 1} appeared early')
        if not during[y0:y1, :, 3].any():
            raise ValueError(f'ROW_AUDIT_FAIL: line {i + 1} did not enter')
        if not np.array_equal(after[:y1], src[:y1]):
            raise ValueError(f'ROW_AUDIT_FAIL: line {i + 1} incomplete or previous pixels changed')
        if during[y1:, :, 3].any():
            raise ValueError(f'ROW_AUDIT_FAIL: future pixels visible during line {i + 1}')
        checks.append({'index': i + 1, 'start': round(start, 6),
                       'end': round(end, 6), 'before_hidden': True,
                       'entered': True, 'settled_rgba_exact': True})
    if not np.array_equal(frame(animation_end - TRANSITION_DURATION), src):
        raise ValueError('ROW_AUDIT_FAIL: final transition would conceal missing foreground')
    return checks


def sequential_text_layer(text_layer, t, row_units, animation_end):
    """Reveal one visible text row/card at a time; the source has no separate title layer."""
    import numpy as np
    from PIL import Image
    src = np.asarray(text_layer)
    out = src.copy()
    out[:, :, 3] = 0

    def reveal(y0, y1, progress):
        unit = src[y0:y1].copy()
        unit[:, :, 3] = np.rint(unit[:, :, 3] * progress).astype('uint8')
        columns = np.flatnonzero(src[y0:y1, :, 3].max(axis=0))
        dx = round(min(2, text_layer.width - 1 - int(columns[-1])) * (1.0 - progress)) if columns.size else 0
        if dx:
            out[y0:y1, dx:] = unit[:, :-dx]
        else:
            out[y0:y1] = unit

    bands = row_bands(row_units, 0, text_layer.height)
    for (y0, y1), (start, end) in zip(bands, row_schedule(row_units, 0.0, animation_end)):
        reveal(y0, y1, _smoothstep((t - start) / (end - start)))
    return Image.fromarray(out)


def audit_text_row_timing(text_layer, row_units, animation_end):
    """Reject a whole-layer fade or any future text row leaking into the animation."""
    import numpy as np
    src = np.asarray(text_layer)
    bands = row_bands(row_units, 0, text_layer.height)
    schedule = row_schedule(row_units, 0.0, animation_end)

    def frame(t):
        return np.asarray(sequential_text_layer(text_layer, t, row_units, animation_end))

    if frame(0)[:, :, 3].any():
        raise ValueError('TEXT_ROW_AUDIT_FAIL: text is visible on the first frame')
    checks = []
    for i, ((y0, y1), (start, end)) in enumerate(zip(bands, schedule)):
        before = frame(max(0, start - 1e-6))
        during = frame((start + end) / 2)
        after = frame(end + 1e-6)
        if before[y0:y1, :, 3].any():
            raise ValueError(f'TEXT_ROW_AUDIT_FAIL: row {i + 1} appeared early')
        if not during[y0:y1, :, 3].any():
            raise ValueError(f'TEXT_ROW_AUDIT_FAIL: row {i + 1} did not enter')
        if not np.array_equal(after[:y1], src[:y1]):
            raise ValueError(f'TEXT_ROW_AUDIT_FAIL: row {i + 1} did not settle exactly')
        if during[y1:, :, 3].any():
            raise ValueError(f'TEXT_ROW_AUDIT_FAIL: future row appeared during row {i + 1}')
        checks.append({'row': i + 1, 'start': round(start, 6), 'end': round(end, 6),
                       'before_hidden': True, 'during_visible': True, 'settled_rgba_exact': True})
    if not np.array_equal(frame(animation_end - TRANSITION_DURATION), src):
        raise ValueError('TEXT_ROW_AUDIT_FAIL: incomplete text before final transition')
    return checks


def text_poster_frame(t, background, text_layer, final, row_units, animation_end):
    """Create the reveal frame before the supplied/composed final image is held."""
    from PIL import Image
    if t >= animation_end:
        return final.convert('RGB')
    scale_end = max(.1, animation_end - TRANSITION_DURATION)
    scale = 1 + .025 * math.sin(math.pi * min(1.0, t / scale_end)) ** 2
    w, h = background.size
    bg = background if abs(scale - 1) < 1e-12 else background.transform(
        (w, h), Image.Transform.AFFINE,
        (1 / scale, 0, w / 2 - w / (2 * scale), 0, 1 / scale, h / 2 - h / (2 * scale)),
        resample=Image.Resampling.BICUBIC)
    frame = Image.alpha_composite(bg.convert('RGBA'),
                                  sequential_text_layer(text_layer, t, row_units, animation_end)).convert('RGB')
    mix = min(1, max(0, (t - (animation_end - TRANSITION_DURATION)) / TRANSITION_DURATION))
    return Image.blend(frame, final.convert('RGB'), mix) if mix else frame


def poster_frame(t, background, foreground, final, row_units, title_height,
                 animation_end, title_end, body_start):
    from PIL import Image
    if t >= animation_end:
        return final.convert('RGB')
    scale_end = max(body_start + 0.1, animation_end - TRANSITION_DURATION)
    scale = 1 + 0.025 * math.sin(math.pi * min(1.0, t / scale_end))**2
    w, h = background.size
    if abs(scale-1) < 1e-12:
        bg = background
    else:
        bg = background.transform((w,h), Image.Transform.AFFINE,
             (1/scale,0,w/2-w/(2*scale),0,1/scale,h/2-h/(2*scale)),
             resample=Image.Resampling.BICUBIC)
    fg = sequential_foreground(foreground, t, title_height, title_end,
                               row_units, body_start, animation_end)
    frame = Image.alpha_composite(bg, fg).convert('RGB')
    mix = min(1, max(0, (t - (animation_end - TRANSITION_DURATION)) / TRANSITION_DURATION))
    return Image.blend(frame, final.convert('RGB'), mix) if mix else frame


def even_frame(frame):
    import numpy as np
    from PIL import Image
    w,h=frame.size
    if w%2 or h%2:
        return Image.fromarray(np.pad(np.asarray(frame),((0,h%2),(0,w%2),(0,0)),mode='edge'))
    return frame


def breathe(base, t, start):
    from PIL import Image
    if t <= start:
        return base
    scale = 1 + .006*(1-math.cos(2*math.pi*(t-start)/BREATH_PERIOD))
    if abs(scale-1) < 1e-12:
        return base
    w,h = base.size
    return base.transform((w,h), Image.Transform.AFFINE,
        (1/scale,0,w/2-w/(2*scale),0,1/scale,h/2-h/(2*scale)),
        resample=Image.Resampling.BICUBIC)


def render_poster(job, work, sound):
    from PIL import Image
    from watermark import Mark
    from audio_source import packet_timing
    bg,fg,final=image(job['background']),image(job['foreground']),image(job['final'])
    if bg.size != fg.size or bg.size != final.size:
        raise ValueError('The three image canvases must share identical dimensions and coordinates')
    for im in (bg,final):
        if im.getchannel('A').getextrema() != (255,255):
            raise ValueError('Background and final must be opaque')
    if fg.getchannel('A').getextrema()[0] == 255:
        raise ValueError('Foreground has no transparent region')
    supplied_bounds=job.get('bounds')
    title_height=infer_title_height(fg, job.get('title_height', 0), supplied_bounds)
    row_units=infer_row_units(fg, title_height, job.get('line_units'), supplied_bounds)
    if not row_units:
        raise ValueError('No body line units could be inferred from the transparent foreground')
    if not 0 < title_height < fg.height:
        raise ValueError('title_height could not be inferred from the transparent foreground')
    animation_end=animation_duration(row_units,title_height)
    title_end=min(TITLE_REVEAL_MAX, max(0.45, animation_end*0.28))
    body_start=title_end
    row_timing_audit=audit_row_timing(fg,title_height,title_end,row_units,
                                      body_start,animation_end)
    expected=Image.alpha_composite(bg,fg).convert('RGB')
    # The supplied three images may be visually related exports rather than a
    # mathematically exact split.  Keep the difference as an audit result but
    # do not block production: animate background+foreground, then crossfade
    # to the supplied final image at the dynamic end point.
    recomposed=compare(expected,final.convert('RGB'))
    full=poster_frame(animation_end,bg,fg,final,row_units,title_height,
                      animation_end,title_end,body_start)
    assert compare(full,final.convert('RGB'))['different_pixels']==0
    D=sound['duration']; k=min(1,D/6)
    count=(sound['duration_ticks']*30+sound['timescale']-1)//sound['timescale']
    if count < 3:
        raise ValueError('Audio is too short to show a reveal and finished picture')
    tail=animation_end*k
    end_base=final.convert('RGB')
    mark=Mark(job,bg.width,bg.height,0.0,D,work)
    def frame_at(t):
        anim_t=t/k
        base=breathe(end_base,t,tail) if t>=tail else poster_frame(
            anim_t,bg,fg,final,row_units,title_height,animation_end,title_end,body_start)
        return mark.apply(base,t)
    samples=work/'samples';samples.mkdir(exist_ok=True)
    for old in samples.glob('*.png'):old.unlink()
    indices={0,count-1}
    indices.update(min(count-1,round(t*30)) for t in (
        body_start*k, title_end*k, (animation_end-TRANSITION_DURATION)*k,
        animation_end*k, 0.65, 1.45, 2.65, tail+BREATH_PERIOD))
    for i in sorted(indices):
        frame_at(i/30).save(samples/f'{i:04d}.png')
    w,h=bg.size;ew,eh=w+w%2,h+h%2
    target=work/'final_animation.partial.mp4'
    args=['ffmpeg','-y','-v','error','-f','rawvideo','-pixel_format','rgb24',
          '-video_size',f'{ew}x{eh}','-framerate','30','-i','pipe:0']
    if sound['has_audio']:
        args+=['-i',sound['path'],'-map','0:v:0','-map','1:a:0','-c:a','copy']
    else:
        args+=['-map','0:v:0','-an']
    args+=['-c:v','libx264','-preset',job.get('preset',DEFAULT_PRESET),
          '-crf',str(job.get('crf',DEFAULT_CRF)),
          '-profile:v',VIDEO_PROFILE,'-level',VIDEO_LEVEL,
          '-maxrate',VIDEO_MAXRATE,'-bufsize',VIDEO_BUFSIZE,
          '-tune','stillimage','-bf','0','-fps_mode','passthrough',
          '-bsf:v',packet_timing(sound,count,(count-1)/30,cfr=True),
          '-video_track_timescale',str(sound['timescale']),'-movie_timescale',str(sound['timescale']),
          '-avoid_negative_ts','disabled','-pix_fmt','yuv420p','-movflags','+faststart',str(target)]
    with open(work/'encode.log','ab') as log:
        proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=log,stderr=log)
        try:
            for i in range(count):
                proc.stdin.write(even_frame(frame_at(i/30)).tobytes())
            proc.stdin.close()
            if proc.wait()!=0:
                raise RuntimeError((work/'encode.log').read_text(errors='replace')[-2000:])
        except BaseException:
            proc.kill();proc.wait();raise
    return {'path':str(target),'width':ew,'height':eh,'source_width':w,'source_height':h,
            'frame_count':count,'pts':[i/30 for i in range(count)],'duration':D,
            'audio_count':int(sound['has_audio']),'sound':sound,'watermark':mark.report,
            'animation':{'end':animation_end,'title_end':title_end,
                         'body_start':body_start,'title_height':title_height,
                         'row_units': [{**timing, 'y0':a, 'y1':b}
                                       for (a,b),timing in zip(row_units,row_timing_audit)],
                         'row_count':len(row_units)},
            'row_timing_audit':row_timing_audit,
            'layer_recomposition':recomposed,
            'pixel_match_required':False,
            'breathing':{'start':tail,'period':BREATH_PERIOD,'max_scale':1.012}}


def render_text_poster(job, work, sound):
    """Render one transparent text layer over one supplied background image."""
    from PIL import Image
    from watermark import Mark
    from audio_source import packet_timing
    bg, text = image(job['background']), image(job['text_layer'])
    if bg.size != text.size:
        raise ValueError('background and text_layer must share one canvas and coordinates')
    if bg.getchannel('A').getextrema() != (255, 255):
        raise ValueError('background must be opaque')
    if text.getchannel('A').getextrema()[0] == 255:
        raise ValueError('text_layer must be a transparent PNG with visible text')
    if job.get('final'):
        final = image(job['final'])
        if final.size != bg.size or final.getchannel('A').getextrema() != (255, 255):
            raise ValueError('final must be an opaque image on the background canvas')
    else:
        final = Image.alpha_composite(bg.convert('RGBA'), text).convert('RGB')
    row_units = infer_row_units(text, 0, job.get('line_units'))
    if not row_units:
        raise ValueError('No visible text row or text card could be inferred from text_layer')
    animation_end = animation_duration(row_units, 0)
    row_timing_audit = audit_text_row_timing(text, row_units, animation_end)
    recomposed = compare(Image.alpha_composite(bg.convert('RGBA'), text).convert('RGB'), final.convert('RGB'))
    settled = text_poster_frame(animation_end, bg, text, final, row_units, animation_end)
    if compare(settled, final.convert('RGB'))['different_pixels']:
        raise ValueError('Final transition does not end at the supplied/composed final image')
    duration = sound['duration']
    speed = min(1, duration / 6)
    count = (sound['duration_ticks'] * FPS + sound['timescale'] - 1) // sound['timescale']
    if count < 3:
        raise ValueError('Audio is too short to show text animation and a finished picture')
    tail = animation_end * speed
    mark = Mark(job, bg.width, bg.height, 0.0, duration, work)

    def frame_at(t):
        animation_time = t / speed
        base = breathe(final.convert('RGB'), t, tail) if t >= tail else text_poster_frame(
            animation_time, bg, text, final, row_units, animation_end)
        return mark.apply(base, t)

    samples = work / 'samples'; samples.mkdir(exist_ok=True)
    for old in samples.glob('*.png'):
        old.unlink()
    indices = {0, count - 1}
    indices.update(min(count - 1, round(t * FPS)) for t in (
        0.0, (animation_end - TRANSITION_DURATION) * speed, animation_end * speed,
        tail + BREATH_PERIOD, .65, 1.45, 2.65))
    for i in sorted(indices):
        frame_at(i / FPS).save(samples / f'{i:04d}.png')
    w, h = bg.size; ew, eh = w + w % 2, h + h % 2
    target = work / 'final_animation.partial.mp4'
    args = ['ffmpeg','-y','-v','error','-f','rawvideo','-pixel_format','rgb24',
            '-video_size',f'{ew}x{eh}','-framerate',str(FPS),'-i','pipe:0']
    if sound['has_audio']:
        args += ['-i',sound['path'],'-map','0:v:0','-map','1:a:0','-c:a','copy']
    else:
        args += ['-map','0:v:0','-an']
    args += ['-c:v','libx264','-preset',job.get('preset',DEFAULT_PRESET),
             '-crf',str(job.get('crf',DEFAULT_CRF)),'-profile:v',VIDEO_PROFILE,
             '-level',VIDEO_LEVEL,'-maxrate',VIDEO_MAXRATE,'-bufsize',VIDEO_BUFSIZE,
             '-tune','stillimage','-bf','0','-fps_mode','passthrough',
             '-bsf:v',packet_timing(sound,count,(count - 1) / FPS,cfr=True),
             '-video_track_timescale',str(sound['timescale']),'-movie_timescale',str(sound['timescale']),
             '-avoid_negative_ts','disabled','-pix_fmt','yuv420p','-movflags','+faststart',str(target)]
    with open(work / 'encode.log','ab') as log:
        proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=log, stderr=log)
        try:
            for i in range(count):
                proc.stdin.write(even_frame(frame_at(i / FPS)).tobytes())
            proc.stdin.close()
            if proc.wait() != 0:
                raise RuntimeError((work / 'encode.log').read_text(errors='replace')[-2000:])
        except BaseException:
            proc.kill(); proc.wait(); raise
    return {'path':str(target),'width':ew,'height':eh,'source_width':w,'source_height':h,
            'frame_count':count,'pts':[i / FPS for i in range(count)],'duration':duration,
            'audio_count':int(sound['has_audio']),'sound':sound,'watermark':mark.report,
            'animation':{'end':animation_end,'row_count':len(row_units),
                         'row_units':[{**timing,'y0':a,'y1':b}
                                      for (a,b),timing in zip(row_units,row_timing_audit)]},
            'row_timing_audit':row_timing_audit,'layer_recomposition':recomposed,
            'pixel_match_required':False,
            'breathing':{'start':tail,'period':BREATH_PERIOD,'max_scale':1.012}}


def render_video_title_body(job, work, sound):
    """No opaque background was supplied: fit independent title/body over one blue video."""
    from PIL import Image
    from watermark import Mark
    from audio_source import packet_timing
    raw_title, raw_body = image(job['title_layer']), image(job['body_layer'])
    for label, layer in (('title_layer', raw_title), ('body_layer', raw_body)):
        extrema = layer.getchannel('A').getextrema()
        if extrema[1] == 0 or extrema[0] == 255:
            raise ValueError(f'{label} must be a non-empty transparent PNG')
    source = prepare_video_background(job, digest(job['title_layer']) + digest(job['body_layer']))
    background = source['preview']
    title_box = normalize_box(job.get('title_box', DEFAULT_TITLE_BOX), 'title_box')
    body_box = normalize_box(job.get('body_box', DEFAULT_BODY_BOX), 'body_box')
    title, title_layout = fit_title(raw_title, background.size, title_box)
    title_bbox = visible_alpha_bbox(title)
    body, body_layout = fit_body(raw_body, background.size, title_bbox, body_box)
    foreground = Image.alpha_composite(title, body)
    title_height = title_bbox[3]
    row_units = infer_row_units(foreground, title_height, job.get('line_units'))
    if not row_units:
        raise ValueError('No body line units could be inferred from body_layer')
    animation_end = animation_duration(row_units, title_height)
    title_end = min(TITLE_REVEAL_MAX, max(.45, animation_end * .28))
    body_start = title_end
    row_timing_audit = audit_row_timing(foreground, title_height, title_end, row_units,
                                        body_start, animation_end)
    duration = sound['duration']; k = min(1.0, duration / 6.0)
    count = (sound['duration_ticks'] * FPS + sound['timescale'] - 1) // sound['timescale']
    if count < 3:
        raise ValueError('Audio is too short to show title and body')
    tail = animation_end * k
    end_background = video_background_frame(source, max(0.0, duration - 1 / FPS))
    mark = Mark(job, background.width, background.height, 0.0, duration, work)

    def frame_at(t, video_frame):
        anim_t = t / k
        visible_foreground = sequential_foreground(
            foreground, min(anim_t, animation_end), title_height, title_end, row_units,
            body_start, animation_end)
        base = Image.alpha_composite(video_frame.convert('RGBA'), visible_foreground).convert('RGB')
        if t >= tail:
            base = breathe(base, t, tail)
        return mark.apply(base, t)

    samples = work / 'samples'; samples.mkdir(exist_ok=True)
    for old in samples.glob('*.png'):
        old.unlink()
    indices = {0, count - 1}
    indices.update(min(count - 1, round(t * FPS)) for t in (
        body_start * k, title_end * k, (animation_end - TRANSITION_DURATION) * k,
        animation_end * k, .65, 1.45, 2.65, tail + BREATH_PERIOD))
    for i in sorted(indices):
        sample_bg = video_background_frame(source, i / FPS)
        frame_at(i / FPS, sample_bg).save(samples / f'{i:04d}.png')

    w, h = background.size; ew, eh = w + w % 2, h + h % 2
    target = work / 'final_animation.partial.mp4'
    args = ['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pixel_format', 'rgb24',
            '-video_size', f'{ew}x{eh}', '-framerate', str(FPS), '-i', 'pipe:0']
    if sound['has_audio']:
        args += ['-i', sound['path'], '-map', '0:v:0', '-map', '1:a:0', '-c:a', 'copy']
    else:
        args += ['-map', '0:v:0', '-an']
    args += ['-c:v', 'libx264', '-preset', job.get('preset', DEFAULT_PRESET),
             '-crf', str(job.get('crf', DEFAULT_CRF)), '-profile:v', VIDEO_PROFILE,
             '-level', VIDEO_LEVEL, '-maxrate', VIDEO_MAXRATE, '-bufsize', VIDEO_BUFSIZE,
             '-tune', 'stillimage', '-bf', '0', '-fps_mode', 'passthrough',
             '-bsf:v', packet_timing(sound, count, (count - 1) / FPS, cfr=True),
             '-video_track_timescale', str(sound['timescale']), '-movie_timescale', str(sound['timescale']),
             '-avoid_negative_ts', 'disabled', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(target)]
    repeated = False
    with open(work / 'encode.log', 'ab') as log:
        encoder = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=log, stderr=log)
        reader = None
        try:
            reader, repeated = open_video_background_reader(source, count, duration, log)
            byte_count = ew * eh * 3
            for i in range(count):
                raw = reader.stdout.read(byte_count)
                if len(raw) != byte_count:
                    raise RuntimeError('Background video ended before all planned output frames were decoded')
                video_frame = Image.frombytes('RGB', (ew, eh), raw)
                encoder.stdin.write(even_frame(frame_at(i / FPS, video_frame)).tobytes())
            encoder.stdin.close()
            if encoder.wait() != 0:
                raise RuntimeError((work / 'encode.log').read_text(errors='replace')[-2000:])
            reader.stdout.close()
            if reader.wait() != 0:
                raise RuntimeError((work / 'encode.log').read_text(errors='replace')[-2000:])
        except BaseException:
            if encoder.poll() is None:
                encoder.kill()
            encoder.wait()
            if reader is not None:
                if reader.poll() is None:
                    reader.kill()
                reader.wait()
            raise
    if repeated:
        loop_policy = 'repeat_source_from_first_frame_in_original_order_then_trim_to_final_duration'
    elif duration < source['source_duration'] - 1e-9:
        loop_policy = 'use_source_once_from_start_then_trim_excess_at_final_output_duration'
    else:
        loop_policy = 'use_source_once_exactly_to_final_output_duration'
    return {'path': str(target), 'width': ew, 'height': eh, 'source_width': w, 'source_height': h,
            'frame_count': count, 'pts': [i / FPS for i in range(count)], 'duration': duration,
            'audio_count': int(sound['has_audio']), 'sound': sound, 'watermark': mark.report,
            'branch': 'VIDEO_FALLBACK_NO_BACKGROUND_IMAGE',
            'background_video': {'source_name': source['source_name'], 'selection': source['selection'],
                                 'source_duration': source['source_duration'], 'source_size': source['source_size'],
                                 'source_audio_used': False, 'repeated': repeated,
                                 'loop_policy': loop_policy, 'output_duration': duration},
            'layout': {'title_box': list(title_box), 'body_box': list(body_box),
                       'title': title_layout, 'body': body_layout,
                       'policy': 'measure_visible_alpha_then_adapt_title_and_body_to_safe_zones'},
            'animation': {'end': animation_end, 'title_end': title_end, 'body_start': body_start,
                          'title_height': title_height,
                          'row_units': [{**timing, 'y0': a, 'y1': b}
                                        for (a, b), timing in zip(row_units, row_timing_audit)],
                          'row_count': len(row_units)},
            'row_timing_audit': row_timing_audit, 'pixel_match_required': False,
            'breathing': {'start': tail, 'period': BREATH_PERIOD, 'max_scale': 1.012}}


def verify_movie(path,expected,work):
    info=probe(path);detailed=probe(path,True);v=video_stream(info);pts=frame_times(detailed)
    if v['codec_name']!='h264' or (v['width'],v['height'])!=(expected['width'],expected['height']):
        raise ValueError('Output codec or dimensions differ from plan')
    if len(pts)!=expected['frame_count']:
        raise ValueError(f'Frame count mismatch: {len(pts)} / {expected["frame_count"]}')
    tick=float(Fraction(v['time_base']))
    err=max(abs(a-b) for a,b in zip(pts,expected['pts']))
    if err>tick+2e-6:raise ValueError(f'Presentation timestamps changed: max {err}s / tick {tick}s')
    if abs(float(v['duration'])-expected['duration'])>max(tick*2,2e-5):
        raise ValueError(f'Duration changed: {v["duration"]} / {expected["duration"]}')
    audio=[s for s in info['streams'] if s['codec_type']=='audio']
    if len(audio)!=expected['audio_count']:raise ValueError('Audio tracks missing or added')
    sound=expected.get('sound')
    if sound and sound['has_audio']:
        a=audio[0]
        if a['channels']!=sound['channels'] or int(a['sample_rate'])!=sound['sample_rate']:
            raise ValueError('Source audio channels or sample rate changed')
        tolerance=max(2/sound['sample_rate'],2e-6)
        if abs(float(a['duration'])-sound['audio_duration'])>tolerance:
            raise ValueError(f'Audio duration changed: {a["duration"]} / {sound["audio_duration"]}')
        if abs(float(a.get('start_time',0))-sound['mux_offset'])>tolerance:
            raise ValueError('Source audio start time changed')
    if expected.get('fps') and v['r_frame_rate']!=expected['fps']:
        raise ValueError('Frame rate changed')
    command(['ffmpeg','-v','error','-xerror','-i',str(path),'-map','0:v:0','-map','0:a?',
             '-f','null','-'],work/'decode.log')
    return {'engine_version':VERSION,'codec':'h264','width':v['width'],'height':v['height'],'frames':len(pts),
            'duration':float(v['duration']),'max_pts_error':err,'audio_tracks':len(audio),
            'full_decode':'passed','watermark':expected.get('watermark',{'enabled':False}),
            'sound':sound,'breathing':expected.get('breathing'),
            'animation':expected.get('animation'),
            'row_timing_audit':expected.get('row_timing_audit'),
            'layer_recomposition':expected.get('layer_recomposition'),
            'pixel_match_required':expected.get('pixel_match_required',False),
            'branch':expected.get('branch','THREE_BACKGROUND_IMAGE'),
            'background_video':expected.get('background_video'),
            'layout':expected.get('layout')}


def package_movie(movie,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    movie=Path(movie)
    expected_hash=digest(movie)
    ztemp=out/'MP4.partial.zip'
    with zipfile.ZipFile(ztemp,'w',zipfile.ZIP_STORED) as z:
        z.write(movie,'final_animation.mp4')
    with zipfile.ZipFile(ztemp) as z:
        assert z.namelist()==['final_animation.mp4']
        h=hashlib.sha256()
        with z.open('final_animation.mp4') as stream:
            for part in iter(lambda:stream.read(1048576),b''):
                h.update(part)
        assert h.hexdigest()==expected_hash
    ztemp.replace(out/'MP4.zip')
    return {'zip':str(out/'MP4.zip'),'mp4_sha256':expected_hash,
            'mp4_bytes':movie.stat().st_size,'package_bytes_identical':True}


def run_job(job_path):
    import watermark
    import audio_source
    status=check_environment()
    if not status['ready']:raise RuntimeError(f'Missing dependencies: {status["missing"]}')
    job_path=Path(job_path).resolve();job=json.loads(job_path.read_text())
    if job.get('mode') != 'TEXT_SINGLE':
        raise ValueError('mode must be TEXT_SINGLE')
    common={'mode','text_layer','line_units','work_dir','output_dir','crf','preset','watermark','audio_source','video_audio_source','reference_video','audio_stream'}
    allowed=common|{'background','final'}
    if set(job)-allowed:
        raise ValueError(f'Unsupported parameters (not silently ignored): {sorted(set(job)-allowed)}')
    required=('background','text_layer')
    branch='TEXT_SINGLE_BACKGROUND_IMAGE'
    for key in required:
        if not job.get(key):
            raise ValueError(f'Missing required input: {key}')
    for key in ('background','text_layer','final','audio_source','video_audio_source','reference_video','work_dir','output_dir'):
        if job.get(key):job[key]=str((job_path.parent/Path(job[key])).resolve())
    for key in required:
        if not Path(job[key]).is_file():
            raise FileNotFoundError(job[key])
    work=Path(job.get('work_dir',job_path.parent/'work'));work.mkdir(parents=True,exist_ok=True)
    out=Path(job.get('output_dir',job_path.parent/'delivery'))
    input_keys=tuple(required)+tuple(k for k in ('final','audio_source','video_audio_source','reference_video')
                                          if job.get(k) and k not in required)
    inputs={k:('UNAVAILABLE' if k in ('reference_video','video_audio_source','audio_source') and not Path(job[k]).is_file()
               else digest(job[k])) for k in input_keys if job.get(k)}
    render_job={k:v for k,v in job.items() if k not in ('output_dir','work_dir')}
    fp=hashlib.sha256(json.dumps({'job':render_job,'inputs':inputs,'engine':digest(__file__),
        'watermark_engine':watermark.fingerprint(job),'audio_engine':digest(audio_source.__file__)},sort_keys=True).encode()).hexdigest()
    record=work/'job_state.json';state=json.loads(record.read_text()) if record.exists() else {}
    final=work/'final_animation.mp4'
    start=time.monotonic()
    if (state.get('fingerprint')==fp and state.get('movie_verified') and final.exists()
        and state.get('mp4_sha256')==digest(final)):
        result=state['movie_verified']
    else:
        write_json(record,{'fingerprint':fp,'stage':'rendering','inputs':inputs,'engine_version':VERSION})
        sound=audio_source.prepare(job,work,probe,command)
        expected=render_text_poster(job,work,sound)
        result=verify_movie(expected['path'],expected,work)
        Path(expected['path']).replace(final)
        state={'fingerprint':fp,'stage':'video_verified','inputs':inputs,'engine_version':VERSION,'branch':branch,
               'movie_verified':result,'mp4_sha256':digest(final)}
        write_json(record,state)
    packaged=package_movie(final,out)
    state.update({'stage':'packaged','delivery':packaged,'elapsed_this_run_seconds':round(time.monotonic()-start,3),
                  'visual_review':'agent must inspect samples and assets before claiming complete'})
    write_json(record,state)
    return {**result,**packaged,'state':str(record),'elapsed_seconds':state['elapsed_this_run_seconds']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    subs=parser.add_subparsers(dest='command',required=True)
    subs.add_parser('doctor')
    run=subs.add_parser('run');run.add_argument('job')
    p=subs.add_parser('package',help='Package an already verified MP4 without rendering or encoding')
    p.add_argument('--movie',required=True);p.add_argument('--out',required=True)
    args=parser.parse_args()
    try:
        if args.command=='doctor':result=check_environment()
        elif args.command=='run':result=run_job(args.job)
        elif args.command=='package':result=package_movie(args.movie,args.out)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        if args.command=='doctor' and not result['ready']:sys.exit(2)
    except Exception as exc:
        print(json.dumps({'error':str(exc),'command':args.command},ensure_ascii=False),file=sys.stderr)
        sys.exit(1)


if __name__=='__main__':main()
